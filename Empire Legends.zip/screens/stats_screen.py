"""Stats & Achievements Screen - English"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivymd.uix.progressbar import MDProgressBar
from kivy.metrics import dp
from game_data import TRIBES, ACHIEVEMENTS_DEF


class StatsScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.player = None
        self._build_ui()


    def _go_back(self, *a):
        self.manager.current = "village"

    def _build_ui(self):
        self.md_bg_color = (0.04, 0.04, 0.06, 1)
        root = MDBoxLayout(orientation="vertical")

        hdr = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(50),
            padding=dp(8), md_bg_color=(0.02,0.02,0.04,1))
        back = MDIconButton(icon="arrow-right", theme_text_color="Custom",
            text_color=(1,1,1,1), size_hint_x=None, width=dp(40))
        back.bind(on_release=self._go_back)
        title = MDLabel(text="Stats & Achievements", font_style="H6",
            theme_text_color="Custom", text_color=(0.6,0.6,1,1), halign="center")
        hdr.add_widget(title)
        hdr.add_widget(back)

        tabs = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(40),
            md_bg_color=(0.06,0.06,0.09,1))
        self.tab_btns = {}
        for tid, tname in [("stats","Statistics"),("achievements","Achievements")]:
            btn = MDFlatButton(text=tname, font_size="13sp",
                theme_text_color="Custom", text_color=(0.55,0.55,0.55,1))
            btn.bind(on_release=lambda x, t=tid: self._switch(t))
            self.tab_btns[tid] = btn
            tabs.add_widget(btn)

        self.scroll = ScrollView()
        self.content = MDBoxLayout(orientation="vertical", spacing=dp(8),
            padding=dp(8), size_hint_y=None)
        self.content.bind(minimum_height=self.content.setter("height"))
        self.scroll.add_widget(self.content)

        root.add_widget(hdr)
        root.add_widget(tabs)
        root.add_widget(self.scroll)
        self.add_widget(root)

    def on_enter(self):
        self.player = self.manager.player
        self._switch("stats")

    def _switch(self, tab_id):
        for tid, btn in self.tab_btns.items():
            btn.text_color = (0.6,0.6,1,1) if tid == tab_id else (0.5,0.5,0.5,1)
        self.content.clear_widgets()
        if tab_id == "stats":
            self._show_stats()
        else:
            self._show_achievements()

    def _show_stats(self):
        p = self.player
        tribe_name = TRIBES.get(p.tribe, {}).get("name", p.tribe)

        # Profile card
        profile = MDCard(orientation="vertical", size_hint_y=None, height=dp(170),
            padding=dp(14), spacing=dp(6),
            md_bg_color=(0.08,0.08,0.13,1), radius=[dp(12)])
        profile.add_widget(MDLabel(text=f"{p.name}  -  {tribe_name}",
            font_style="H6", theme_text_color="Custom",
            text_color=(1,0.82,0.2,1), halign="center"))
        profile.add_widget(MDLabel(text=f"Village: {p.village_name}",
            font_style="Subtitle2", theme_text_color="Custom",
            text_color=(0.8,0.8,0.9,1), halign="center"))
        xp_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(22))
        xp_row.add_widget(MDLabel(text=f"Lv{p.level}", font_style="Caption",
            theme_text_color="Custom", text_color=(0.9,0.7,0.2,1),
            size_hint_x=None, width=dp(36), halign="center"))
        xp_bar = MDProgressBar(value=p.experience, max=p.next_level_xp, color=(0.9,0.7,0.1,1))
        xp_row.add_widget(xp_bar)
        xp_row.add_widget(MDLabel(text=f"{p.experience}/{p.next_level_xp}",
            font_style="Caption", theme_text_color="Custom",
            text_color=(0.7,0.7,0.5,1), size_hint_x=None, width=dp(80), halign="right"))
        profile.add_widget(xp_row)
        profile.add_widget(MDLabel(text=f"Achievement Points: {p.achievement_points}",
            font_style="Caption", theme_text_color="Custom",
            text_color=(0.6,0.6,1,1), halign="center"))
        self.content.add_widget(profile)

        # Stats sections
        sections = [
            ("Combat", [
                ("Army size",         p.get_army_count()),
                ("Attack power",      p.get_attack_power()),
                ("Defense power",     p.get_defense_power()),
                ("Attacks sent",      p.attacks_sent),
                ("Victories",         p.attacks_won),
                ("Resources looted",  f"{p.resources_looted:,}"),
                ("Enemy killed",      p.total_kills),
            ]),
            ("Village", [
                ("Population",        p.population),
                ("Buildings upgraded",p.buildings_built),
                ("Units trained",     p.units_trained),
                ("Wood/h",            p.production_rate["wood"]),
                ("Clay/h",            p.production_rate["clay"]),
                ("Iron/h",            p.production_rate["iron"]),
                ("Crop/h",            p.production_rate["crop"]),
            ]),
            ("Social", [
                ("Alliance",          p.alliance_name or "None"),
                ("Alliance role",     p.alliance_role  or "-"),
                ("Quests today",      f"{len(p.daily_quests_completed)}/{len(__import__('game_data').DAILY_QUESTS)}"),
                ("Unread messages",   p.get_unread_count()),
            ]),
        ]
        for sec_name, items in sections:
            h = 30 + len(items) * 34
            sec = MDCard(orientation="vertical", size_hint_y=None, height=dp(h),
                padding=[dp(12),dp(8)], spacing=dp(2),
                md_bg_color=(0.07,0.07,0.11,1), radius=[dp(10)])
            sec.add_widget(MDLabel(text=f"--- {sec_name} ---",
                font_style="Caption", theme_text_color="Custom",
                text_color=(0.6,0.6,0.85,1), halign="center", size_hint_y=None, height=dp(24)))
            for label, value in items:
                row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(28))
                row.add_widget(MDLabel(text=str(label), font_style="Body2",
                    theme_text_color="Custom", text_color=(0.72,0.72,0.78,1), halign="left"))
                row.add_widget(MDLabel(text=str(value), font_style="Body2",
                    theme_text_color="Custom", text_color=(1,0.85,0.3,1),
                    halign="right", size_hint_x=None, width=dp(130)))
                sec.add_widget(row)
            self.content.add_widget(sec)

    def _show_achievements(self):
        p = self.player
        # Check & unlock
        for ach in ACHIEVEMENTS_DEF:
            if ach["id"] not in p.achievements:
                if getattr(p, ach["field"], 0) >= ach["target"]:
                    p.achievements.append(ach["id"])
                    p.achievement_points += ach["pts"]

        done  = len(p.achievements)
        total = len(ACHIEVEMENTS_DEF)
        hdr = MDCard(orientation="horizontal", size_hint_y=None, height=dp(46),
            padding=dp(10), md_bg_color=(0.08,0.08,0.13,1), radius=[dp(8)])
        hdr.add_widget(MDLabel(
            text=f"Achievements: {done}/{total}   Points: {p.achievement_points}",
            font_style="Subtitle1", theme_text_color="Custom",
            text_color=(0.6,0.6,1,1), halign="center"))
        self.content.add_widget(hdr)

        ICON_MAP = {
            "hammer":"hammer","city-variant":"city-variant","sword":"sword",
            "shield":"shield","trophy":"trophy","crown":"crown",
            "cash":"cash","fire":"fire","star":"star","medal":"medal",
        }
        for ach in ACHIEVEMENTS_DEF:
            field_val = getattr(p, ach["field"], 0)
            is_done   = ach["id"] in p.achievements
            pct       = min(100, (field_val / ach["target"] * 100)) if ach["target"] else 100

            bg = (0.08,0.1,0.08,1) if is_done else (0.07,0.07,0.1,1)
            card = MDCard(orientation="vertical", size_hint_y=None, height=dp(88),
                padding=[dp(10),dp(6)], spacing=dp(4),
                md_bg_color=bg, radius=[dp(8)])

            top = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(32))
            ic  = ICON_MAP.get(ach["icon"], "star")
            ic_c= (0.3,0.9,0.4,1) if is_done else (0.5,0.5,0.5,1)
            top.add_widget(MDIconButton(icon=ic, theme_text_color="Custom",
                text_color=ic_c, size_hint_x=None, width=dp(36)))
            nb = MDBoxLayout(orientation="vertical")
            nc = (0.5,0.9,0.55,1) if is_done else (0.8,0.8,0.85,1)
            nb.add_widget(MDLabel(text=ach["name"], font_style="Subtitle2",
                theme_text_color="Custom", text_color=nc))
            nb.add_widget(MDLabel(text=ach["desc"], font_style="Caption",
                theme_text_color="Custom", text_color=(0.6,0.6,0.65,1)))
            top.add_widget(nb)
            top.add_widget(MDLabel(text=f"+{ach['pts']}pt", font_style="Caption",
                theme_text_color="Custom",
                text_color=(0.9,0.75,0.2,1) if is_done else (0.4,0.4,0.4,1),
                size_hint_x=None, width=dp(46), halign="center"))
            card.add_widget(top)
            card.add_widget(MDProgressBar(value=pct, max=100,
                color=(0.3,0.85,0.4,1) if is_done else (0.5,0.5,0.7,1),
                size_hint_y=None, height=dp(6)))
            card.add_widget(MDLabel(
                text=f"{min(field_val,ach['target'])}/{ach['target']}" + (" - Done!" if is_done else ""),
                font_style="Caption", theme_text_color="Custom",
                text_color=(0.6,0.65,0.6,1), halign="left", size_hint_y=None, height=dp(16)))
            self.content.add_widget(card)

        from utils.save_manager import save_game
        save_game(p)

"""Map Screen - World Map & Battles"""
import random
from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivymd.uix.dialog import MDDialog
from kivy.uix.widget import Widget
from kivy.metrics import dp
from kivy.graphics import Color, Rectangle, Ellipse, Line
from game_data import WORLD_VILLAGES, RESOURCES

CELL     = dp(46)
GRID_SZ  = 20


class WorldMapWidget(Widget):
    def __init__(self, villages, player_pos, on_tap, **kwargs):
        super().__init__(**kwargs)
        self.villages    = villages
        self.player_pos  = player_pos
        self.on_tap      = on_tap
        self.size        = (CELL * GRID_SZ, CELL * GRID_SZ)
        self.size_hint   = (None, None)
        self._areas      = []
        self.bind(pos=self._draw, size=self._draw)
        self._draw()

    def _draw(self, *a):
        self.canvas.clear()
        self._areas = []
        with self.canvas:
            Color(0.04, 0.08, 0.03, 1)
            Rectangle(pos=self.pos, size=self.size)
            Color(0.08, 0.13, 0.06, 1)
            for i in range(GRID_SZ + 1):
                x = self.x + i * CELL
                Line(points=[x, self.y, x, self.y + self.height], width=0.5)
                y = self.y + i * CELL
                Line(points=[self.x, y, self.x + self.width, y], width=0.5)
            # Player village
            px = self.x + self.player_pos["x"] * CELL
            py = self.y + self.player_pos["y"] * CELL
            r  = CELL * 0.4
            Color(0.2, 0.95, 0.3, 1)
            Ellipse(pos=(px-r, py-r), size=(r*2, r*2))
            # World villages
            for v in self.villages:
                vx = self.x + v["x"] * CELL
                vy = self.y + v["y"] * CELL
                r2 = CELL * 0.3
                if v["owner"] == "NPC":
                    Color(0.8,0.3,0.3,0.9) if v["def"]<60 else (Color(0.9,0.5,0.1,0.9) if v["def"]<300 else Color(0.7,0.1,0.1,0.9))
                else:
                    Color(0.25, 0.45, 0.9, 0.9)
                Ellipse(pos=(vx-r2, vy-r2), size=(r2*2, r2*2))
                self._areas.append((v, vx, vy, r2 + dp(10)))

    def on_touch_down(self, touch):
        for v, vx, vy, r in self._areas:
            if (touch.x-vx)**2 + (touch.y-vy)**2 <= r*r:
                self.on_tap(v)
                return True
        return super().on_touch_down(touch)


class MapScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.player = None
        self.dialog = None
        self._build_ui()


    def _go_back(self, *a):
        self.manager.current = "village"

    def _build_ui(self):
        self.md_bg_color = (0.04, 0.07, 0.02, 1)
        root = MDBoxLayout(orientation="vertical")

        hdr = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(50),
            padding=dp(8), md_bg_color=(0.02,0.04,0.01,1))
        back = MDIconButton(icon="arrow-right", theme_text_color="Custom",
            text_color=(1,1,1,1), size_hint_x=None, width=dp(40))
        back.bind(on_release=self._go_back)
        self.title_lbl = MDLabel(text="World Map", font_style="H6",
            theme_text_color="Custom", text_color=(0.5,1,0.3,1), halign="center")
        quest_btn = MDIconButton(icon="format-list-checks",
            theme_text_color="Custom", text_color=(1,0.9,0.3,1),
            size_hint_x=None, width=dp(40))
        quest_btn.bind(on_release=lambda x: setattr(self.manager,"current","quests"))
        hdr.add_widget(self.title_lbl)
        hdr.add_widget(quest_btn)
        hdr.add_widget(back)

        legend = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(28),
            padding=[dp(8),0], spacing=dp(8), md_bg_color=(0.03,0.05,0.01,1))
        for txt, col in [("You",(0.2,0.95,0.3,1)),("Easy NPC",(0.8,0.3,0.3,1)),
                          ("Medium NPC",(0.9,0.5,0.1,1)),("Hard NPC",(0.7,0.1,0.1,1)),
                          ("Player",(0.25,0.45,0.9,1))]:
            legend.add_widget(MDLabel(text=txt, font_style="Caption",
                theme_text_color="Custom", text_color=col, halign="center"))

        self.map_scroll = ScrollView(do_scroll_x=True, do_scroll_y=True, size_hint=(1,1))
        self.map_widget = None

        list_lbl = MDLabel(text="Villages - tap to attack:",
            font_style="Caption", theme_text_color="Custom",
            text_color=(0.6,0.7,0.5,1), halign="left",
            size_hint_y=None, height=dp(22), padding=[dp(8),0])

        self.list_scroll = ScrollView(size_hint_y=None, height=dp(200))
        self.vlist = MDBoxLayout(orientation="vertical", size_hint_y=None,
            spacing=dp(4), padding=dp(6))
        self.vlist.bind(minimum_height=self.vlist.setter("height"))
        self.list_scroll.add_widget(self.vlist)

        root.add_widget(hdr)
        root.add_widget(legend)
        root.add_widget(self.map_scroll)
        root.add_widget(list_lbl)
        root.add_widget(self.list_scroll)
        self.add_widget(root)

    def on_enter(self):
        self.player = self.manager.player
        self.map_scroll.clear_widgets()
        pv = {"x": self.player.village_x, "y": self.player.village_y}
        self.map_widget = WorldMapWidget(WORLD_VILLAGES, pv, self._village_tap)
        self.map_scroll.add_widget(self.map_widget)
        from kivy.clock import Clock
        Clock.schedule_once(lambda dt: self._scroll_to_player(), 0.2)
        self._build_list()

    def _scroll_to_player(self):
        self.map_scroll.scroll_x = max(0, min(1, self.player.village_x / GRID_SZ - 0.2))
        self.map_scroll.scroll_y = max(0, min(1, self.player.village_y / GRID_SZ - 0.2))

    def _build_list(self):
        self.vlist.clear_widgets()
        for v in WORLD_VILLAGES:
            bg = (0.13,0.07,0.07,1) if v["owner"]=="NPC" else (0.07,0.1,0.15,1)
            card = MDCard(orientation="horizontal", size_hint_y=None, height=dp(54),
                padding=[dp(8),dp(4)], spacing=dp(8),
                md_bg_color=bg, radius=[dp(6)])
            info = MDBoxLayout(orientation="vertical")
            info.add_widget(MDLabel(text=f"{v['name']} ({v['x']},{v['y']})",
                font_style="Subtitle2", theme_text_color="Custom", text_color=(1,0.88,0.6,1)))
            info.add_widget(MDLabel(
                text=f"Pop:{v['pop']}  DEF:{v['def']}  Resources:{v['res']}  [{v['owner']}]",
                font_style="Caption", theme_text_color="Custom", text_color=(0.6,0.6,0.6,1)))
            btn = MDRaisedButton(text="Attack", font_size="11sp",
                size_hint_x=None, width=dp(66), md_bg_color=(0.6,0.1,0.1,1))
            btn.bind(on_release=lambda x, vil=v: self._village_tap(vil))
            card.add_widget(info)
            card.add_widget(btn)
            self.vlist.add_widget(card)

    def _village_tap(self, v):
        p   = self.player
        atk = p.get_attack_power()
        win = min(90, max(10, int((atk / max(1,v["def"])) * 45)))
        diff= "Easy" if v["def"]<60 else ("Medium" if v["def"]<300 else "Hard")
        msg = (f"Location: ({v['x']},{v['y']})\nPop: {v['pop']}\n"
               f"Resources: {v['res']:,}\nDefense: {v['def']} [{diff}]\n"
               f"Owner: {v['owner']}\n\nYour army: {p.get_army_count()} units\n"
               f"Attack power: {atk}\nWin chance: {win}%")
        self._close_dialog()
        self.dialog = MDDialog(title=v["name"], text=msg, buttons=[
            MDFlatButton(text="Close", on_release=lambda x: self._close_dialog()),
            MDRaisedButton(text="ATTACK!", md_bg_color=(0.7,0.1,0.1,1),
                on_release=lambda x: self._do_attack(v)),
        ])
        self.dialog.open()

    def _do_attack(self, v):
        self._close_dialog()
        res = self.player.conduct_attack(v)
        from utils.save_manager import save_game
        save_game(self.player)
        if not res["success"]:
            self._info("Notice", res["msg"]); return
        if res["win"]:
            loot_str = "  ".join(f"{RESOURCES[r]['icon']}{a}" for r,a in res["loot"].items() if a>0)
            msg = (f"VICTORY!\n\nLoot: {loot_str}\n"
                   f"Enemy killed: {res['kills']}\nYour casualties: {res['casualties']}")
            if res.get("healed",0) > 0:
                msg += f"\nHealed in hospital: {res['healed']}"
            self._info("Victory!", msg)
        else:
            msg = f"DEFEATED!\n\nYour casualties: {res['casualties']}"
            if res.get("healed",0) > 0:
                msg += f"\nHealed in hospital: {res['healed']}"
            self._info("Defeated", msg)

    def _info(self, title, msg):
        self._close_dialog()
        self.dialog = MDDialog(title=title, text=msg, buttons=[
            MDRaisedButton(text="OK", on_release=lambda x: self._close_dialog())])
        self.dialog.open()

    def _close_dialog(self, *a):
        if self.dialog:
            self.dialog.dismiss()
            self.dialog = None

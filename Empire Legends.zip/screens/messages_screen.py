"""Messages Screen - English - Fixed back button"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivymd.uix.dialog import MDDialog
from kivymd.uix.textfield import MDTextField
from kivy.metrics import dp


class MessagesScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.player        = None
        self.dialog        = None
        self._compose_open = False
        self._build_ui()

    def _go_back(self, *a):
        self.manager.current = "village"

    def _build_ui(self):
        self.md_bg_color = (0.04, 0.05, 0.07, 1)
        root = MDBoxLayout(orientation="vertical")

        # Header
        hdr = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(50),
            padding=dp(8), md_bg_color=(0.02, 0.03, 0.05, 1))
        back = MDIconButton(icon="arrow-right", theme_text_color="Custom",
            text_color=(1,1,1,1), size_hint_x=None, width=dp(40))
        back.bind(on_release=self._go_back)
        self.title_lbl = MDLabel(text="Messages", font_style="H6",
            theme_text_color="Custom", text_color=(0.4,0.7,1,1), halign="center")
        compose_btn = MDIconButton(icon="pencil-plus", theme_text_color="Custom",
            text_color=(0.6,0.9,1,1), size_hint_x=None, width=dp(40))
        compose_btn.bind(on_release=lambda x: self._toggle_compose())
        hdr.add_widget(self.title_lbl)
        hdr.add_widget(compose_btn)
        hdr.add_widget(back)

        # Tabs
        tabs = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(40),
            md_bg_color=(0.06,0.07,0.1,1))
        self.tab_btns = {}
        for tid, tname in [("inbox","Inbox"),("sent","Sent")]:
            btn = MDFlatButton(text=tname, font_size="13sp",
                theme_text_color="Custom", text_color=(0.55,0.55,0.55,1))
            btn.bind(on_release=lambda x, t=tid: self._switch(t))
            self.tab_btns[tid] = btn
            tabs.add_widget(btn)

        # Compose panel
        self.compose_panel = MDBoxLayout(orientation="vertical",
            size_hint_y=None, height=0, padding=dp(8), spacing=dp(6),
            md_bg_color=(0.06,0.08,0.12,1))
        self.compose_panel.opacity = 0
        self.to_field   = MDTextField(hint_text="To:", mode="rectangle",
            size_hint_y=None, height=dp(44))
        self.subj_field = MDTextField(hint_text="Subject:", mode="rectangle",
            size_hint_y=None, height=dp(44))
        self.body_field = MDTextField(hint_text="Message...", mode="rectangle",
            multiline=False, size_hint_y=None, height=dp(44))
        send_btn = MDRaisedButton(text="Send", md_bg_color=(0.2,0.5,0.8,1),
            size_hint_y=None, height=dp(36))
        send_btn.bind(on_release=self._send_msg)
        for w in [self.to_field, self.subj_field, self.body_field, send_btn]:
            self.compose_panel.add_widget(w)

        # Content
        self.scroll = ScrollView()
        self.content = MDBoxLayout(orientation="vertical", spacing=dp(6),
            padding=dp(8), size_hint_y=None)
        self.content.bind(minimum_height=self.content.setter("height"))
        self.scroll.add_widget(self.content)

        root.add_widget(hdr)
        root.add_widget(tabs)
        root.add_widget(self.compose_panel)
        root.add_widget(self.scroll)
        self.add_widget(root)

    def on_enter(self):
        self.player = self.manager.player
        if not self.player.inbox:
            self.player.inbox = [
                {"id":1,"from":"Game System","subject":"Welcome to Travian!",
                 "body":f"Hello {self.player.name}! Build your village, train your army, and conquer the world!",
                 "time":"2026-07-10 01:00","read":False},
                {"id":2,"from":"Khalid","subject":"Alliance Invitation",
                 "body":"We are Knights of East alliance looking for strong players. Want to join us?",
                 "time":"2026-07-10 02:00","read":False},
            ]
        self._switch("inbox")

    def _toggle_compose(self):
        self._compose_open = not self._compose_open
        self.compose_panel.height  = dp(220) if self._compose_open else 0
        self.compose_panel.opacity = 1        if self._compose_open else 0

    def _switch(self, tab_id):
        for tid, btn in self.tab_btns.items():
            btn.text_color = (0.4,0.7,1,1) if tid==tab_id else (0.5,0.5,0.5,1)
        self.content.clear_widgets()
        if tab_id == "inbox":
            self._show_inbox()
        else:
            self._show_sent()

    def _show_inbox(self):
        if not self.player.inbox:
            self.content.add_widget(MDLabel(text="No messages.", font_style="Body1",
                theme_text_color="Custom", text_color=(0.5,0.5,0.5,1),
                halign="center", size_hint_y=None, height=dp(80)))
            return
        for msg in reversed(self.player.inbox):
            unread = not msg.get("read", True)
            bg = (0.08,0.1,0.15,1) if unread else (0.06,0.07,0.1,1)
            card = MDCard(orientation="vertical", size_hint_y=None, height=dp(72),
                padding=[dp(10),dp(6)], spacing=dp(4),
                md_bg_color=bg, radius=[dp(8)], ripple_behavior=True)
            row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(28))
            row.add_widget(MDLabel(text=f"From: {msg.get('from','')}",
                font_style="Subtitle2", theme_text_color="Custom",
                text_color=(0.4,0.8,1,1) if unread else (0.6,0.65,0.7,1), halign="left"))
            if unread:
                row.add_widget(MDLabel(text="NEW", font_style="Caption",
                    theme_text_color="Custom", text_color=(0.3,0.9,0.5,1),
                    size_hint_x=None, width=dp(40), halign="center"))
            row.add_widget(MDLabel(text=str(msg.get("time",""))[:10],
                font_style="Caption", theme_text_color="Custom",
                text_color=(0.45,0.45,0.5,1), size_hint_x=None, width=dp(80), halign="right"))
            card.add_widget(row)
            card.add_widget(MDLabel(text=msg.get("subject",""), font_style="Body2",
                theme_text_color="Custom", text_color=(0.85,0.85,0.9,1), halign="left"))
            card.bind(on_release=lambda x, m=msg: self._open_msg(m))
            self.content.add_widget(card)

    def _show_sent(self):
        if not self.player.sent_messages:
            self.content.add_widget(MDLabel(text="No sent messages.", font_style="Body1",
                theme_text_color="Custom", text_color=(0.5,0.5,0.5,1),
                halign="center", size_hint_y=None, height=dp(80)))
            return
        for msg in reversed(self.player.sent_messages):
            card = MDCard(orientation="vertical", size_hint_y=None, height=dp(72),
                padding=[dp(10),dp(6)], spacing=dp(4),
                md_bg_color=(0.06,0.07,0.1,1), radius=[dp(8)])
            row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(28))
            row.add_widget(MDLabel(text=f"To: {msg.get('to','')}",
                font_style="Subtitle2", theme_text_color="Custom",
                text_color=(0.6,0.65,0.7,1), halign="left"))
            row.add_widget(MDLabel(text=str(msg.get("time",""))[:10],
                font_style="Caption", theme_text_color="Custom",
                text_color=(0.45,0.45,0.5,1), size_hint_x=None, width=dp(80), halign="right"))
            card.add_widget(row)
            card.add_widget(MDLabel(text=msg.get("subject",""), font_style="Body2",
                theme_text_color="Custom", text_color=(0.75,0.75,0.8,1), halign="left"))
            self.content.add_widget(card)

    def _open_msg(self, msg):
        msg["read"] = True
        from utils.save_manager import save_game
        save_game(self.player)
        self._close_dialog()
        self.dialog = MDDialog(
            title=msg.get("subject","Message"),
            text=f"From: {msg.get('from','')}\n\n{msg.get('body','')}",
            buttons=[
                MDFlatButton(text="Close",
                    on_release=lambda x: self._close_dialog()),
                MDRaisedButton(text="Reply",
                    md_bg_color=(0.2,0.45,0.75,1),
                    on_release=lambda x: self._reply(msg.get("from",""))),
            ])
        self.dialog.open()
        self._switch("inbox")

    def _reply(self, to_name):
        self._close_dialog()
        self.to_field.text = to_name
        if not self._compose_open:
            self._toggle_compose()

    def _send_msg(self, *a):
        to   = self.to_field.text.strip()
        subj = self.subj_field.text.strip()
        body = self.body_field.text.strip()
        if not to:
            self._info("Notice", "Enter recipient name!")
            return
        self.player.send_message(to, subj or "(No Subject)", body or "...")
        from utils.save_manager import save_game
        save_game(self.player)
        self.to_field.text = self.subj_field.text = self.body_field.text = ""
        self._toggle_compose()
        self._switch("sent")

    def _info(self, title, msg):
        self._close_dialog()
        self.dialog = MDDialog(title=title, text=msg,
            buttons=[MDRaisedButton(text="OK",
                on_release=lambda x: self._close_dialog())])
        self.dialog.open()

    def _close_dialog(self, *a):
        if self.dialog:
            self.dialog.dismiss()
            self.dialog = None

"""Village Screen - Main Hub"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.gridlayout import MDGridLayout
from kivy.uix.scrollview import ScrollView
from kivymd.uix.progressbar import MDProgressBar
from kivymd.uix.dialog import MDDialog
from kivy.metrics import dp
from kivy.clock import Clock
from game_data import BUILDINGS, RESOURCES, UNITS


class ResBar(MDBoxLayout):
    def __init__(self, rkey, rdata, **kwargs):
        super().__init__(orientation="vertical", size_hint_y=None,
            height=dp(54), padding=dp(2), **kwargs)
        top = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(24))
        top.add_widget(MDLabel(text=rdata["icon"], font_style="Caption",
            theme_text_color="Custom", text_color=(1,1,1,1),
            size_hint_x=None, width=dp(20), halign="center"))
        self.amt = MDLabel(text="0", font_style="Caption",
            theme_text_color="Custom", text_color=(1,1,1,1), halign="center")
        self.rate = MDLabel(text="+0", font_style="Caption",
            theme_text_color="Custom", text_color=(0.5,0.9,0.5,1),
            size_hint_x=None, width=dp(34), halign="right")
        top.add_widget(self.amt)
        top.add_widget(self.rate)
        self.bar = MDProgressBar(value=0, max=100, color=rdata["color"],
            size_hint_y=None, height=dp(6))
        self.add_widget(top)
        self.add_widget(self.bar)

    def update(self, amount, maxv, rate):
        self.amt.text  = f"{int(amount):,}"
        self.rate.text = f"+{int(rate)}"
        self.bar.value = min(100, (amount/maxv*100) if maxv > 0 else 0)


class VillageScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.player      = None
        self.dialog      = None
        self._tick_ev    = None
        self.current_tab = "resource"
        self._build_ui()

    def _build_ui(self):
        self.md_bg_color = (0.06, 0.04, 0.02, 1)
        root = MDBoxLayout(orientation="vertical")

        # --- Header ---
        hdr = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(50),
            padding=[dp(8),dp(4)], spacing=dp(2), md_bg_color=(0.04,0.02,0.0,1))
        self.village_lbl = MDLabel(text="Village", font_style="H6",
            theme_text_color="Custom", text_color=(1,0.82,0.2,1), halign="left")
        self.level_lbl = MDLabel(text="Lv1", font_style="Caption",
            theme_text_color="Custom", text_color=(0.7,0.8,1,1),
            size_hint_x=None, width=dp(36), halign="center")
        self.pop_lbl = MDLabel(text="Pop:5", font_style="Caption",
            theme_text_color="Custom", text_color=(0.7,0.8,1,1),
            size_hint_x=None, width=dp(52), halign="center")
        self.msg_btn = MDIconButton(icon="email", size_hint_x=None, width=dp(36),
            theme_text_color="Custom", text_color=(1,1,1,1))
        self.msg_btn.bind(on_release=lambda x: self._go("messages"))
        al_btn = MDIconButton(icon="shield-account", size_hint_x=None, width=dp(36),
            theme_text_color="Custom", text_color=(0.7,0.5,1,1))
        al_btn.bind(on_release=lambda x: self._go("alliance"))
        st_btn = MDIconButton(icon="chart-bar", size_hint_x=None, width=dp(36),
            theme_text_color="Custom", text_color=(0.5,0.8,1,1))
        st_btn.bind(on_release=lambda x: self._go("stats"))
        map_btn = MDIconButton(icon="map", size_hint_x=None, width=dp(36),
            theme_text_color="Custom", text_color=(0.4,1,0.4,1))
        map_btn.bind(on_release=lambda x: self._go("map"))
        hdr.add_widget(self.village_lbl)
        hdr.add_widget(self.level_lbl)
        hdr.add_widget(self.pop_lbl)
        hdr.add_widget(self.msg_btn)
        hdr.add_widget(al_btn)
        hdr.add_widget(st_btn)
        hdr.add_widget(map_btn)

        # --- Resources ---
        res_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(62),
            padding=dp(4), spacing=dp(4), md_bg_color=(0.08,0.06,0.03,1))
        self.res_bars = {}
        for rk, rd in RESOURCES.items():
            bar = ResBar(rk, rd)
            self.res_bars[rk] = bar
            res_row.add_widget(bar)

        # --- XP Bar ---
        xp_row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(20),
            padding=[dp(8),0], md_bg_color=(0.06,0.05,0.02,1))
        self.xp_lbl = MDLabel(text="XP:0/500", font_style="Caption",
            theme_text_color="Custom", text_color=(0.8,0.8,0.6,1),
            size_hint_x=None, width=dp(90), halign="left")
        self.xp_bar = MDProgressBar(value=0, max=100, color=(0.9,0.7,0.1,1))
        xp_row.add_widget(self.xp_lbl)
        xp_row.add_widget(self.xp_bar)

        # --- Tabs ---
        tabs = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(40),
            md_bg_color=(0.1,0.07,0.04,1))
        self.tab_btns = {}
        for tid, tname in [("resource","Resources"),("military","Military"),
                            ("village","Village"),("economy","Economy")]:
            btn = MDFlatButton(text=tname, font_size="12sp",
                theme_text_color="Custom", text_color=(0.55,0.55,0.45,1))
            btn.bind(on_release=lambda x, t=tid: self.switch_tab(t))
            self.tab_btns[tid] = btn
            tabs.add_widget(btn)

        # --- Content ---
        self.scroll = ScrollView()
        self.content = MDBoxLayout(orientation="vertical", spacing=dp(8),
            padding=dp(8), size_hint_y=None)
        self.content.bind(minimum_height=self.content.setter("height"))
        self.scroll.add_widget(self.content)

        root.add_widget(hdr)
        root.add_widget(res_row)
        root.add_widget(xp_row)
        root.add_widget(tabs)
        root.add_widget(self.scroll)
        self.add_widget(root)

    # ===== Lifecycle =====
    def on_enter(self):
        self.player = self.manager.player
        self.player.update_resources()
        self.player.reset_daily_quests()
        self._refresh()
        self._tick_ev = Clock.schedule_interval(self._tick, 6)

    def on_leave(self):
        if self._tick_ev:
            self._tick_ev.cancel()

    def _tick(self, dt):
        if self.player:
            self.player.update_resources()
            self._update_res()

    def _refresh(self):
        self._update_res()
        self._update_hdr()
        self.switch_tab(self.current_tab)

    def _update_hdr(self):
        p = self.player
        self.village_lbl.text = p.village_name
        self.level_lbl.text   = f"Lv{p.level}"
        self.pop_lbl.text     = f"Pop:{p.population}"
        self.msg_btn.icon     = "email-alert" if p.get_unread_count() > 0 else "email"
        self.xp_lbl.text      = f"XP:{p.experience}/{p.next_level_xp}"
        self.xp_bar.value     = (p.experience / p.next_level_xp * 100) if p.next_level_xp else 0

    def _update_res(self):
        p = self.player
        for rk, bar in self.res_bars.items():
            bar.update(p.resources[rk], p.max_resources[rk], p.production_rate[rk])

    # ===== Tabs =====
    def switch_tab(self, tab_id):
        self.current_tab = tab_id
        for tid, btn in self.tab_btns.items():
            btn.text_color = (1,0.82,0.2,1) if tid == tab_id else (0.45,0.45,0.35,1)
        self.content.clear_widgets()
        if tab_id == "military":
            self._show_military()
        else:
            cat = {"resource":"resource","village":"village","economy":"economy"}.get(tab_id,"village")
            self._show_buildings_by_cat(cat)

    def _show_buildings_by_cat(self, cat):
        blds = {bid: bd for bid, bd in BUILDINGS.items() if bd.get("category") == cat}
        grid = MDGridLayout(cols=2, spacing=dp(6), size_hint_y=None, adaptive_height=True)
        for bid, bd in blds.items():
            lvl  = self.player.buildings.get(bid, 0)
            grid.add_widget(self._make_bld_card(bid, bd, lvl))
        self.content.add_widget(grid)

    def _make_bld_card(self, bid, bd, lvl):
        card = MDCard(orientation="vertical", size_hint_y=None, height=dp(108),
            padding=dp(8), spacing=dp(4), md_bg_color=(0.13,0.1,0.06,1),
            radius=[dp(8)], ripple_behavior=True)
        top = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(40))
        top.add_widget(MDLabel(text=bd["icon"], font_style="Subtitle1",
            theme_text_color="Custom", text_color=(1,0.82,0.2,1),
            size_hint_x=None, width=dp(42), halign="center"))
        info = MDBoxLayout(orientation="vertical")
        info.add_widget(MDLabel(text=bd["name"], font_style="Subtitle2",
            theme_text_color="Custom", text_color=(1,0.9,0.6,1)))
        status = f"Lv{lvl}" if lvl > 0 else "Not built"
        if lvl > 0 and bd.get("produces"):
            status += f"  +{self.player.production_rate.get(bd['produces'],0)}/h"
        info.add_widget(MDLabel(text=status, font_style="Caption",
            theme_text_color="Custom", text_color=(0.6,0.6,0.6,1)))
        top.add_widget(info)
        card.add_widget(top)
        bar = MDProgressBar(value=lvl, max=bd.get("max_level",20),
            color=(0.8,0.55,0.1,1), size_hint_y=None, height=dp(5))
        card.add_widget(bar)
        max_lv = bd.get("max_level", 20)
        if lvl >= max_lv:
            btn_txt, btn_col = "MAX", (0.2,0.45,0.2,1)
        elif lvl > 0:
            btn_txt, btn_col = f"Upgrade Lv{lvl}->{lvl+1}", (0.55,0.33,0.05,1)
        else:
            btn_txt, btn_col = "Build", (0.4,0.2,0.05,1)
        btn = MDRaisedButton(text=btn_txt, font_size="11sp",
            size_hint_y=None, height=dp(30), md_bg_color=btn_col)
        btn.bind(on_release=lambda x, b=bid: self._on_upgrade(b))
        card.add_widget(btn)
        return card

    def _show_military(self):
        p = self.player
        # Army summary
        summary = MDCard(orientation="horizontal", size_hint_y=None, height=dp(52),
            padding=dp(8), md_bg_color=(0.1,0.08,0.05,1), radius=[dp(8)])
        summary.add_widget(MDLabel(
            text=f"Army: {p.get_army_count()}  |  ATK: {p.get_attack_power()}  |  DEF: {p.get_defense_power()}",
            theme_text_color="Custom", text_color=(1,0.82,0.2,1), halign="center"))
        self.content.add_widget(summary)

        # Units
        for uid, ud in UNITS.items():
            if ud.get("tribe") not in (p.tribe, "all"):
                continue
            count = p.army.get(uid, 0)
            card = MDCard(orientation="horizontal", size_hint_y=None, height=dp(84),
                padding=[dp(8),dp(6)], spacing=dp(8),
                md_bg_color=(0.12,0.09,0.06,1), radius=[dp(8)])
            info = MDBoxLayout(orientation="vertical")
            info.add_widget(MDLabel(text=f"{ud['icon']}  {ud['name']}  x{count}",
                font_style="Subtitle2", theme_text_color="Custom", text_color=(1,0.9,0.6,1)))
            info.add_widget(MDLabel(
                text=f"ATK:{ud['atk']}  DEF:{ud['def_i']}  SPD:{ud['speed']}  CROP:{ud['crop']}",
                font_style="Caption", theme_text_color="Custom", text_color=(0.6,0.6,0.6,1)))
            cost_str = "  ".join(f"{RESOURCES[r]['icon']}{v}" for r,v in ud["cost"].items())
            info.add_widget(MDLabel(text=cost_str, font_style="Caption",
                theme_text_color="Custom", text_color=(0.4,0.7,0.4,1)))
            btns = MDBoxLayout(orientation="vertical", size_hint_x=None,
                width=dp(66), spacing=dp(4))
            t1 = MDRaisedButton(text="x1", font_size="11sp",
                size_hint_y=None, height=dp(30), md_bg_color=(0.5,0.1,0.1,1))
            t1.bind(on_release=lambda x, u=uid: self._on_train(u, 1))
            t5 = MDRaisedButton(text="x5", font_size="11sp",
                size_hint_y=None, height=dp(30), md_bg_color=(0.35,0.07,0.07,1))
            t5.bind(on_release=lambda x, u=uid: self._on_train(u, 5))
            btns.add_widget(t1)
            btns.add_widget(t5)
            card.add_widget(info)
            card.add_widget(btns)
            self.content.add_widget(card)

        # Military buildings
        sep = MDLabel(text="--- Military Buildings ---", font_style="Caption",
            theme_text_color="Custom", text_color=(0.6,0.6,0.5,1),
            halign="center", size_hint_y=None, height=dp(26))
        self.content.add_widget(sep)
        grid = MDGridLayout(cols=2, spacing=dp(6), size_hint_y=None, adaptive_height=True)
        for bid, bd in BUILDINGS.items():
            if bd.get("category") == "military":
                lvl = self.player.buildings.get(bid, 0)
                grid.add_widget(self._make_bld_card(bid, bd, lvl))
        self.content.add_widget(grid)

    # ===== Actions =====
    def _on_upgrade(self, bid):
        bd  = BUILDINGS[bid]
        lvl = self.player.buildings.get(bid, 0)
        if lvl >= bd.get("max_level", 20):
            self._info("Notice", "Building is already at max level!")
            return
        cost = bd["cost"](lvl)
        lines = "\n".join(f"{RESOURCES[r]['icon']} {r}: {amt:,}  (have: {int(self.player.resources.get(r,0)):,})"
                          for r,amt in cost.items())
        ok = self.player.can_afford(cost)
        self._ask(f"Upgrade {bd['name']} Lv{lvl}->{lvl+1}", lines,
                  "Upgrade" if ok else "Not enough resources",
                  (lambda: self._do_upgrade(bid)) if ok else None)

    def _do_upgrade(self, bid):
        ok, msg = self.player.upgrade_building(bid)
        from utils.save_manager import save_game
        save_game(self.player)
        self._close_dialog()
        self._info("Done!" if ok else "Error", msg)
        if ok: self._refresh()

    def _on_train(self, uid, count):
        ud   = UNITS[uid]
        cost = {r: v*count for r,v in ud["cost"].items()}
        lines = "\n".join(f"{RESOURCES[r]['icon']} {r}: {v:,}  (have: {int(self.player.resources.get(r,0)):,})"
                          for r,v in cost.items())
        ok = self.player.can_afford(cost)
        self._ask(f"Train {count}x {ud['name']}", lines,
                  "Train" if ok else "Not enough resources",
                  (lambda: self._do_train(uid, count)) if ok else None)

    def _do_train(self, uid, count):
        ok, msg = self.player.train_unit(uid, count)
        from utils.save_manager import save_game
        save_game(self.player)
        self._close_dialog()
        self._info("Done!" if ok else "Error", msg)
        if ok: self._refresh()

    # ===== Dialogs =====
    def _ask(self, title, msg, ok_text, ok_cb):
        self._close_dialog()
        self.dialog = MDDialog(title=title, text=msg, buttons=[
            MDFlatButton(text="Cancel", on_release=lambda x: self._close_dialog()),
            MDRaisedButton(text=ok_text,
                md_bg_color=(0.3,0.55,0.1,1) if ok_cb else (0.35,0.1,0.1,1),
                on_release=lambda x: ok_cb() if ok_cb else self._close_dialog()),
        ])
        self.dialog.open()

    def _info(self, title, msg):
        self._close_dialog()
        self.dialog = MDDialog(title=title, text=msg, buttons=[
            MDRaisedButton(text="OK", on_release=lambda x: self._close_dialog())])
        self.dialog.open()

    def _close_dialog(self, *a):
        if self.dialog:
            self.dialog.dismiss()
            self.dialog = None

    def _go(self, screen):
        self.manager.current = screen

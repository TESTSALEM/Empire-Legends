"""Quests Screen - English"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivymd.uix.progressbar import MDProgressBar
from kivymd.uix.dialog import MDDialog
from kivy.metrics import dp
from game_data import DAILY_QUESTS, RESOURCES


class QuestsScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.player = None
        self.dialog = None
        self._build_ui()


    def _go_back(self, *a):
        self.manager.current = "map"

    def _build_ui(self):
        self.md_bg_color = (0.04, 0.06, 0.04, 1)
        root = MDBoxLayout(orientation="vertical")

        hdr = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(50),
            padding=dp(8), md_bg_color=(0.02,0.04,0.02,1))
        back = MDIconButton(icon="arrow-right", theme_text_color="Custom",
            text_color=(1,1,1,1), size_hint_x=None, width=dp(40))
        back.bind(on_release=self._go_back)
        title = MDLabel(text="Daily Quests", font_style="H6",
            theme_text_color="Custom", text_color=(0.4,1,0.5,1), halign="center")
        hdr.add_widget(title)
        hdr.add_widget(back)

        self.summary_card = MDCard(orientation="horizontal", size_hint_y=None, height=dp(50),
            padding=[dp(12),dp(8)], md_bg_color=(0.06,0.1,0.06,1), radius=[dp(8)])
        self.summary_lbl = MDLabel(text="Quests completed today: 0/8",
            font_style="Subtitle1", theme_text_color="Custom",
            text_color=(0.5,1,0.55,1), halign="center")
        self.summary_card.add_widget(self.summary_lbl)

        self.scroll = ScrollView()
        self.content = MDBoxLayout(orientation="vertical", spacing=dp(8),
            padding=dp(8), size_hint_y=None)
        self.content.bind(minimum_height=self.content.setter("height"))
        self.scroll.add_widget(self.content)

        root.add_widget(hdr)
        root.add_widget(self.summary_card)
        root.add_widget(self.scroll)
        self.add_widget(root)

    def on_enter(self):
        self.player = self.manager.player
        self.player.reset_daily_quests()
        self._build_quests()

    def _build_quests(self):
        self.content.clear_widgets()
        p    = self.player
        done = len(p.daily_quests_completed)
        self.summary_lbl.text = f"Quests completed today: {done}/{len(DAILY_QUESTS)}"

        for q in DAILY_QUESTS:
            qid      = q["id"]
            progress = p.daily_quests_progress.get(qid, 0)
            target   = q["target"]
            is_done  = qid in p.daily_quests_completed
            is_ready = progress >= target and not is_done

            bg = (0.06,0.12,0.06,1) if is_done else ((0.1,0.14,0.06,1) if is_ready else (0.07,0.09,0.07,1))
            tc = (0.5,0.8,0.5,1)   if is_done else ((0.85,0.95,0.3,1) if is_ready else (0.8,0.85,0.7,1))

            card = MDCard(orientation="vertical", size_hint_y=None, height=dp(120),
                padding=[dp(10),dp(8)], spacing=dp(6), md_bg_color=bg, radius=[dp(10)])

            top = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(32))
            icon_n = "check-circle" if is_done else ("star" if is_ready else "clock-outline")
            ic_col = (0.3,0.9,0.4,1) if is_done else ((0.95,0.9,0.2,1) if is_ready else (0.5,0.5,0.5,1))
            top.add_widget(MDIconButton(icon=icon_n, theme_text_color="Custom",
                text_color=ic_col, size_hint_x=None, width=dp(36)))
            nb = MDBoxLayout(orientation="vertical")
            nb.add_widget(MDLabel(text=q["name"], font_style="Subtitle2",
                theme_text_color="Custom", text_color=tc))
            nb.add_widget(MDLabel(text=q["desc"], font_style="Caption",
                theme_text_color="Custom", text_color=(0.65,0.68,0.62,1)))
            top.add_widget(nb)
            card.add_widget(top)

            pct = min(100, (progress / target * 100)) if target > 0 else 100
            card.add_widget(MDProgressBar(value=pct, max=100,
                color=(0.3,0.85,0.4,1) if is_done else (0.7,0.85,0.2,1),
                size_hint_y=None, height=dp(8)))
            card.add_widget(MDLabel(
                text=f"{min(progress,target)}/{target}" if not is_done else "Completed!",
                font_style="Caption", theme_text_color="Custom",
                text_color=(0.7,0.8,0.6,1), halign="left", size_hint_y=None, height=dp(16)))

            bot = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(32), spacing=dp(6))
            rew = "  ".join(f"{RESOURCES[r]['icon']}{a}" for r,a in q["reward"].items())
            bot.add_widget(MDLabel(text=f"Reward: {rew}  +{q.get('xp',50)}XP",
                font_style="Caption", theme_text_color="Custom",
                text_color=(0.9,0.75,0.3,1), halign="left"))
            if is_done:
                bot.add_widget(MDLabel(text="Claimed", font_style="Caption",
                    theme_text_color="Custom", text_color=(0.4,0.8,0.45,1),
                    size_hint_x=None, width=dp(70), halign="center"))
            elif is_ready:
                cl = MDRaisedButton(text="Claim!", font_size="12sp",
                    size_hint_x=None, width=dp(70), md_bg_color=(0.4,0.7,0.1,1))
                cl.bind(on_release=lambda x, qi=qid: self._claim(qi))
                bot.add_widget(cl)
            else:
                bot.add_widget(MDLabel(text="In progress", font_style="Caption",
                    theme_text_color="Custom", text_color=(0.5,0.5,0.45,1),
                    size_hint_x=None, width=dp(80), halign="center"))
            card.add_widget(bot)
            self.content.add_widget(card)

    def _claim(self, qid):
        ok, msg = self.player.claim_quest_reward(qid)
        from utils.save_manager import save_game
        save_game(self.player)
        self._close_dialog()
        self.dialog = MDDialog(title="Reward" if ok else "Notice", text=msg,
            buttons=[MDRaisedButton(text="OK", on_release=lambda x: self._after_claim())])
        self.dialog.open()

    def _after_claim(self):
        self._close_dialog()
        self._build_quests()

    def _close_dialog(self, *a):
        if self.dialog:
            self.dialog.dismiss()
            self.dialog = None

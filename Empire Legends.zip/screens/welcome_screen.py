"""Welcome / Character Creation Screen"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.card import MDCard
from kivymd.uix.textfield import MDTextField
from kivy.metrics import dp
from game_data import TRIBES, Player


class WelcomeScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.selected_tribe = "roman"
        self.tribe_cards = {}
        self._build_ui()

    def _build_ui(self):
        self.md_bg_color = (0.05, 0.03, 0.01, 1)
        root = MDBoxLayout(orientation="vertical", padding=dp(16), spacing=dp(10))

        root.add_widget(MDLabel(text="TRAVIAN LEGENDS",
            font_style="H5", theme_text_color="Custom",
            text_color=(1, 0.82, 0.2, 1), halign="center",
            size_hint_y=None, height=dp(50)))
        root.add_widget(MDLabel(text="Build. Conquer. Dominate.",
            font_style="Subtitle1", theme_text_color="Custom",
            text_color=(0.8, 0.7, 0.5, 1), halign="center",
            size_hint_y=None, height=dp(28)))

        self.name_field = MDTextField(
            hint_text="Player name", text="Hero",
            mode="rectangle", size_hint_y=None, height=dp(52))
        self.village_field = MDTextField(
            hint_text="Village name", text="My Village",
            mode="rectangle", size_hint_y=None, height=dp(52))
        root.add_widget(self.name_field)
        root.add_widget(self.village_field)

        root.add_widget(MDLabel(text="Choose your tribe:",
            font_style="Subtitle1", theme_text_color="Custom",
            text_color=(1, 0.82, 0.2, 1), halign="left",
            size_hint_y=None, height=dp(30)))

        tribes_row = MDBoxLayout(orientation="horizontal",
            size_hint_y=None, height=dp(130), spacing=dp(8))

        tribe_descs = {
            "roman":  "Balanced\nDual build",
            "gaul":   "Fast\nStrong defense",
            "teuton": "Aggressive\nStrong attack",
        }
        for tid, tdata in TRIBES.items():
            card = MDCard(orientation="vertical", padding=dp(8), spacing=dp(4),
                md_bg_color=(0.12, 0.1, 0.06, 1), radius=[dp(10)], ripple_behavior=True)
            card.tribe_id = tid
            card.add_widget(MDLabel(text=tdata["icon"], font_style="H5",
                halign="center", size_hint_y=None, height=dp(42)))
            card.add_widget(MDLabel(text=tdata["name"], font_style="Caption",
                theme_text_color="Custom", text_color=(1, 0.88, 0.5, 1),
                halign="center", size_hint_y=None, height=dp(20)))
            card.add_widget(MDLabel(text=tribe_descs[tid], font_style="Caption",
                theme_text_color="Custom", text_color=(0.7, 0.7, 0.6, 1),
                halign="center", size_hint_y=None, height=dp(34)))
            card.bind(on_release=lambda x, t=tid: self._select_tribe(t))
            self.tribe_cards[tid] = card
            tribes_row.add_widget(card)

        self.tribe_cards["roman"].md_bg_color = (0.25, 0.18, 0.05, 1)
        root.add_widget(tribes_row)

        self.desc_lbl = MDLabel(
            text="Romans: Dual build + balanced army. Great for beginners.",
            font_style="Caption", theme_text_color="Custom",
            text_color=(0.8, 0.8, 0.6, 1), halign="center",
            size_hint_y=None, height=dp(36))
        root.add_widget(self.desc_lbl)

        start_btn = MDRaisedButton(text="START ADVENTURE!",
            font_size="16sp", size_hint_y=None, height=dp(52),
            md_bg_color=(0.65, 0.38, 0.0, 1))
        start_btn.bind(on_release=self._start_game)
        root.add_widget(start_btn)
        self.add_widget(root)

    def _select_tribe(self, tid):
        for t, c in self.tribe_cards.items():
            c.md_bg_color = (0.25, 0.18, 0.05, 1) if t == tid else (0.12, 0.1, 0.06, 1)
        self.selected_tribe = tid
        descs = {
            "roman":  "Romans: Dual build + balanced army. Great for beginners.",
            "gaul":   "Gauls: Fast cavalry + strong defense. Great for defenders.",
            "teuton": "Teutons: Devastating attack but weak defense. For veterans.",
        }
        self.desc_lbl.text = descs[tid]

    def _start_game(self, *a):
        from utils.save_manager import save_game
        p = Player()
        p.name         = self.name_field.text.strip() or "Hero"
        p.village_name = self.village_field.text.strip() or "My Village"
        p.tribe        = self.selected_tribe
        save_game(p)
        self.manager.player  = p
        self.manager.current = "village"

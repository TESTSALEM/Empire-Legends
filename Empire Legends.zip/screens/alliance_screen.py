"""Alliance Screen - English"""
from kivymd.uix.screen import MDScreen
from kivymd.uix.card import MDCard
from kivymd.uix.label import MDLabel
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivy.uix.scrollview import ScrollView
from kivymd.uix.dialog import MDDialog
from kivymd.uix.textfield import MDTextField
from kivy.metrics import dp
from game_data import FAKE_ALLIANCES

FAKE_MEMBERS = [
    {"name":"Khalid",  "level":15, "power":8500,  "role":"Leader"},
    {"name":"Sara",    "level":12, "power":6200,  "role":"Officer"},
    {"name":"Omar",    "level":10, "power":4800,  "role":"Member"},
    {"name":"Nora",    "level":9,  "power":3900,  "role":"Member"},
    {"name":"Faris",   "level":8,  "power":3200,  "role":"Member"},
]


class AllianceScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.player = None
        self.dialog = None
        self._build_ui()


    def _go_back(self, *a):
        self.manager.current = "village"

    def _build_ui(self):
        self.md_bg_color = (0.05, 0.04, 0.07, 1)
        root = MDBoxLayout(orientation="vertical")

        hdr = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(50),
            padding=dp(8), md_bg_color=(0.03,0.02,0.05,1))
        back = MDIconButton(icon="arrow-right", theme_text_color="Custom",
            text_color=(1,1,1,1), size_hint_x=None, width=dp(40))
        back.bind(on_release=self._go_back)
        self.title_lbl = MDLabel(text="Alliances", font_style="H6",
            theme_text_color="Custom", text_color=(0.7,0.5,1,1), halign="center")
        hdr.add_widget(self.title_lbl)
        hdr.add_widget(back)

        tabs = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(40),
            md_bg_color=(0.07,0.05,0.1,1))
        self.tab_btns = {}
        for tid, tname in [("my","My Alliance"),("list","Rankings"),("members","Members")]:
            btn = MDFlatButton(text=tname, font_size="12sp",
                theme_text_color="Custom", text_color=(0.5,0.5,0.5,1))
            btn.bind(on_release=lambda x, t=tid: self._switch(t))
            self.tab_btns[tid] = btn
            tabs.add_widget(btn)

        self.scroll = ScrollView()
        self.content = MDBoxLayout(orientation="vertical", spacing=dp(8),
            padding=dp(8), size_hint_y=None)
        self.content.bind(minimum_height=self.content.setter("height"))
        self.scroll.add_widget(self.content)

        root.add_widget(hdr)
        root.add_widget(tabs)
        root.add_widget(self.scroll)
        self.add_widget(root)

    def on_enter(self):
        self.player = self.manager.player
        self._switch("my")

    def _switch(self, tab_id):
        for tid, btn in self.tab_btns.items():
            btn.text_color = (0.7,0.5,1,1) if tid == tab_id else (0.5,0.5,0.5,1)
        self.content.clear_widgets()
        {"my": self._show_mine, "list": self._show_list, "members": self._show_members}[tab_id]()

    # ===== My Alliance =====
    def _show_mine(self):
        p = self.player
        if not p.alliance_name:
            self.content.add_widget(MDLabel(text="You are not in any alliance.",
                font_style="H6", theme_text_color="Custom",
                text_color=(0.6,0.6,0.6,1), halign="center",
                size_hint_y=None, height=dp(60)))
            # Create alliance
            create = MDCard(orientation="vertical", size_hint_y=None, height=dp(140),
                padding=dp(12), spacing=dp(8), md_bg_color=(0.1,0.08,0.15,1), radius=[dp(10)])
            create.add_widget(MDLabel(text="Create a new alliance",
                font_style="Subtitle1", theme_text_color="Custom",
                text_color=(0.7,0.5,1,1), halign="center"))
            self.new_name = MDTextField(hint_text="Alliance name",
                mode="rectangle", size_hint_y=None, height=dp(48))
            create.add_widget(self.new_name)
            btn = MDRaisedButton(text="CREATE", md_bg_color=(0.5,0.3,0.8,1),
                size_hint_y=None, height=dp(38))
            btn.bind(on_release=self._create)
            create.add_widget(btn)
            self.content.add_widget(create)
            # Join
            join = MDCard(orientation="vertical", size_hint_y=None, height=dp(76),
                padding=dp(12), spacing=dp(6), md_bg_color=(0.08,0.1,0.15,1), radius=[dp(10)])
            join.add_widget(MDLabel(text="Or join an existing alliance from Rankings tab.",
                font_style="Caption", theme_text_color="Custom",
                text_color=(0.6,0.7,0.9,1), halign="center"))
            go_btn = MDRaisedButton(text="View Rankings", md_bg_color=(0.2,0.35,0.7,1),
                size_hint_y=None, height=dp(34))
            go_btn.bind(on_release=lambda x: self._switch("list"))
            join.add_widget(go_btn)
            self.content.add_widget(join)
        else:
            card = MDCard(orientation="vertical", size_hint_y=None, height=dp(200),
                padding=dp(14), spacing=dp(8), md_bg_color=(0.1,0.08,0.15,1), radius=[dp(12)])
            card.add_widget(MDLabel(text=f"Alliance: {p.alliance_name}",
                font_style="H6", theme_text_color="Custom", text_color=(0.8,0.6,1,1), halign="center"))
            card.add_widget(MDLabel(text=f"Role: {p.alliance_role or 'Member'}",
                font_style="Subtitle1", theme_text_color="Custom", text_color=(1,0.85,0.4,1), halign="center"))
            for line in ["Members: 6","Alliance Power: 25,400","World Rank: #3"]:
                card.add_widget(MDLabel(text=line, font_style="Body2",
                    theme_text_color="Custom", text_color=(0.7,0.7,0.7,1), halign="center"))
            leave = MDRaisedButton(text="Leave Alliance", md_bg_color=(0.5,0.1,0.1,1),
                size_hint_y=None, height=dp(36))
            leave.bind(on_release=self._leave)
            card.add_widget(leave)
            self.content.add_widget(card)

            msg_card = MDCard(orientation="vertical", size_hint_y=None, height=dp(120),
                padding=dp(10), spacing=dp(6), md_bg_color=(0.08,0.07,0.12,1), radius=[dp(8)])
            msg_card.add_widget(MDLabel(text="Message to alliance:",
                font_style="Caption", theme_text_color="Custom",
                text_color=(0.7,0.7,0.8,1), halign="left"))
            self.al_msg = MDTextField(hint_text="Write message...",
                mode="rectangle", size_hint_y=None, height=dp(44))
            msg_card.add_widget(self.al_msg)
            send = MDRaisedButton(text="Send", md_bg_color=(0.3,0.5,0.8,1),
                size_hint_y=None, height=dp(32))
            send.bind(on_release=self._send_al_msg)
            msg_card.add_widget(send)
            self.content.add_widget(msg_card)

    # ===== Rankings =====
    def _show_list(self):
        self.content.add_widget(MDLabel(text="Top Alliances:",
            font_style="Subtitle1", theme_text_color="Custom",
            text_color=(0.7,0.5,1,1), halign="left", size_hint_y=None, height=dp(34)))
        for al in FAKE_ALLIANCES:
            card = MDCard(orientation="horizontal", size_hint_y=None, height=dp(66),
                padding=[dp(10),dp(6)], spacing=dp(8),
                md_bg_color=(0.1,0.08,0.14,1), radius=[dp(8)])
            info = MDBoxLayout(orientation="vertical")
            info.add_widget(MDLabel(text=f"#{al['rank']}  [{al['tag']}] {al['name']}",
                font_style="Subtitle2", theme_text_color="Custom", text_color=(0.8,0.6,1,1)))
            info.add_widget(MDLabel(text=f"Members: {al['members']}   Power: {al['power']:,}",
                font_style="Caption", theme_text_color="Custom", text_color=(0.6,0.6,0.7,1)))
            btn = MDRaisedButton(text="Join", font_size="11sp",
                size_hint_x=None, width=dp(60), md_bg_color=(0.35,0.2,0.65,1))
            btn.bind(on_release=lambda x, a=al: self._join(a))
            card.add_widget(info)
            card.add_widget(btn)
            self.content.add_widget(card)

    # ===== Members =====
    def _show_members(self):
        p = self.player
        if not p.alliance_name:
            self.content.add_widget(MDLabel(text="Join an alliance to see members.",
                font_style="Body1", theme_text_color="Custom",
                text_color=(0.6,0.6,0.6,1), halign="center",
                size_hint_y=None, height=dp(60)))
            return
        members = [{"name": p.name, "level": p.level,
                    "power": p.get_attack_power(), "role": p.alliance_role or "Member"}
                   ] + FAKE_MEMBERS[:5]
        for m in members:
            is_me = m["name"] == p.name
            card = MDCard(orientation="horizontal", size_hint_y=None, height=dp(56),
                padding=[dp(10),dp(6)], spacing=dp(8),
                md_bg_color=(0.1,0.08,0.14,1), radius=[dp(8)])
            info = MDBoxLayout(orientation="vertical")
            nc = (1,0.82,0.2,1) if is_me else (0.8,0.6,1,1)
            info.add_widget(MDLabel(text=f"{m['name']} {'(You)' if is_me else ''}",
                font_style="Subtitle2", theme_text_color="Custom", text_color=nc))
            info.add_widget(MDLabel(text=f"Lv{m['level']}  Power:{m['power']:,}  {m['role']}",
                font_style="Caption", theme_text_color="Custom", text_color=(0.6,0.6,0.7,1)))
            card.add_widget(info)
            if not is_me:
                msg_btn = MDIconButton(icon="email", theme_text_color="Custom",
                    text_color=(0.6,0.7,1,1), size_hint_x=None, width=dp(40))
                msg_btn.bind(on_release=lambda x, mn=m["name"]: self._msg_member(mn))
                card.add_widget(msg_btn)
            self.content.add_widget(card)

    def _create(self, *a):
        name = getattr(self, "new_name", None)
        aname = name.text.strip() if name else ""
        if not aname:
            self._info("Notice", "Enter an alliance name!")
            return
        self.player.alliance_name = aname
        self.player.alliance_role = "Founder"
        from utils.save_manager import save_game
        save_game(self.player)
        self._info("Congrats!", f"Alliance [{aname}] created!")
        self._switch("my")

    def _join(self, al):
        self.player.alliance_name = al["name"]
        self.player.alliance_id   = al["id"]
        self.player.alliance_role = "Member"
        self.player._quest_progress("social", 1)
        from utils.save_manager import save_game
        save_game(self.player)
        self._info("Welcome!", f"You joined [{al['name']}]!")
        self._switch("my")

    def _leave(self, *a):
        self.player.alliance_name = None
        self.player.alliance_id   = None
        self.player.alliance_role = None
        from utils.save_manager import save_game
        save_game(self.player)
        self._switch("my")

    def _send_al_msg(self, *a):
        self.player._quest_progress("social", 1)
        self._info("Sent!", "Message sent to alliance.")
        if hasattr(self, "al_msg"):
            self.al_msg.text = ""

    def _msg_member(self, name):
        self.player.send_message(name, "Hello", f"Hi {name}!")
        from utils.save_manager import save_game
        save_game(self.player)
        self._info("Sent!", f"Message sent to {name}.")

    def _info(self, title, msg):
        self._close_dialog()
        self.dialog = MDDialog(title=title, text=msg, buttons=[
            MDRaisedButton(text="OK", on_release=lambda x: self._close_dialog())])
        self.dialog.open()

    def _close_dialog(self, *a):
        if self.dialog:
            self.dialog.dismiss()
            self.dialog = None

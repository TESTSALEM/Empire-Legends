"""
Travian Legends - Game Data (English)
"""
from datetime import datetime
import random

# ===== RESOURCES =====
RESOURCES = {
    "wood":  {"name": "Wood",  "icon": "W", "color": [0.27, 0.64, 0.27, 1]},
    "clay":  {"name": "Clay",  "icon": "C", "color": [0.87, 0.55, 0.15, 1]},
    "iron":  {"name": "Iron",  "icon": "I", "color": [0.6,  0.6,  0.6,  1]},
    "crop":  {"name": "Crop",  "icon": "Q", "color": [0.95, 0.85, 0.1,  1]},
}

# ===== TRIBES =====
TRIBES = {
    "roman":  {"name": "Romans",  "icon": "R", "bonus": "Dual build"},
    "gaul":   {"name": "Gauls",   "icon": "G", "bonus": "Fast cavalry"},
    "teuton": {"name": "Teutons", "icon": "T", "bonus": "Strong attack"},
}

# ===== BUILDINGS =====
BUILDINGS = {
    "wood_cutter": {
        "name": "Wood Cutter", "icon": "WC", "category": "resource",
        "desc": "Produces Wood", "produces": "wood", "base_prod": 8, "max_level": 10,
        "cost": lambda l: {"wood": int(40*(1.67**l)), "clay": int(40*(1.67**l)), "iron": int(20*(1.67**l)), "crop": int(20*(1.67**l))},
        "build_time": lambda l: int(120*(1.5**l)),
    },
    "clay_pit": {
        "name": "Clay Pit", "icon": "CP", "category": "resource",
        "desc": "Produces Clay", "produces": "clay", "base_prod": 8, "max_level": 10,
        "cost": lambda l: {"wood": int(40*(1.67**l)), "clay": int(40*(1.67**l)), "iron": int(20*(1.67**l)), "crop": int(20*(1.67**l))},
        "build_time": lambda l: int(120*(1.5**l)),
    },
    "iron_mine": {
        "name": "Iron Mine", "icon": "IM", "category": "resource",
        "desc": "Produces Iron", "produces": "iron", "base_prod": 8, "max_level": 10,
        "cost": lambda l: {"wood": int(50*(1.67**l)), "clay": int(50*(1.67**l)), "iron": int(30*(1.67**l)), "crop": int(25*(1.67**l))},
        "build_time": lambda l: int(150*(1.5**l)),
    },
    "cropland": {
        "name": "Cropland", "icon": "CL", "category": "resource",
        "desc": "Produces Crop", "produces": "crop", "base_prod": 8, "max_level": 10,
        "cost": lambda l: {"wood": int(45*(1.67**l)), "clay": int(45*(1.67**l)), "iron": int(25*(1.67**l)), "crop": int(20*(1.67**l))},
        "build_time": lambda l: int(110*(1.5**l)),
    },
    "warehouse": {
        "name": "Warehouse", "icon": "WH", "category": "village",
        "desc": "Increases storage", "max_level": 20,
        "cost": lambda l: {"wood": int(80*(1.28**l)), "clay": int(80*(1.28**l)), "iron": int(80*(1.28**l)), "crop": int(50*(1.28**l))},
        "build_time": lambda l: int(150*(1.4**l)),
    },
    "granary": {
        "name": "Granary", "icon": "GR", "category": "village",
        "desc": "Stores more crop", "max_level": 20,
        "cost": lambda l: {"wood": int(70*(1.28**l)), "clay": int(90*(1.28**l)), "iron": int(70*(1.28**l)), "crop": int(60*(1.28**l))},
        "build_time": lambda l: int(140*(1.4**l)),
    },
    "barracks": {
        "name": "Barracks", "icon": "BR", "category": "military",
        "desc": "Train infantry", "max_level": 20,
        "cost": lambda l: {"wood": int(210*(1.28**l)), "clay": int(140*(1.28**l)), "iron": int(260*(1.28**l)), "crop": int(120*(1.28**l))},
        "build_time": lambda l: int(200*(1.5**l)),
    },
    "stable": {
        "name": "Stable", "icon": "ST", "category": "military",
        "desc": "Train cavalry", "max_level": 20,
        "cost": lambda l: {"wood": int(260*(1.28**l)), "clay": int(140*(1.28**l)), "iron": int(220*(1.28**l)), "crop": int(100*(1.28**l))},
        "build_time": lambda l: int(250*(1.5**l)),
    },
    "workshop": {
        "name": "Workshop", "icon": "WS", "category": "military",
        "desc": "Build siege weapons", "max_level": 20,
        "cost": lambda l: {"wood": int(460*(1.28**l)), "clay": int(510*(1.28**l)), "iron": int(600*(1.28**l)), "crop": int(320*(1.28**l))},
        "build_time": lambda l: int(400*(1.5**l)),
    },
    "academy": {
        "name": "Academy", "icon": "AC", "category": "military",
        "desc": "Research units", "max_level": 20,
        "cost": lambda l: {"wood": int(220*(1.28**l)), "clay": int(160*(1.28**l)), "iron": int(90*(1.28**l)), "crop": int(40*(1.28**l))},
        "build_time": lambda l: int(180*(1.4**l)),
    },
    "rally_point": {
        "name": "Rally Point", "icon": "RP", "category": "military",
        "desc": "Manage armies", "max_level": 5,
        "cost": lambda l: {"wood": int(110*(1.28**l)), "clay": int(160*(1.28**l)), "iron": int(90*(1.28**l)), "crop": int(70*(1.28**l))},
        "build_time": lambda l: int(100*(1.3**l)),
    },
    "marketplace": {
        "name": "Marketplace", "icon": "MP", "category": "economy",
        "desc": "Trade resources", "max_level": 20,
        "cost": lambda l: {"wood": int(80*(1.28**l)), "clay": int(70*(1.28**l)), "iron": int(120*(1.28**l)), "crop": int(70*(1.28**l))},
        "build_time": lambda l: int(120*(1.4**l)),
    },
    "embassy": {
        "name": "Embassy", "icon": "EM", "category": "alliance",
        "desc": "Join alliances", "max_level": 20,
        "cost": lambda l: {"wood": int(180*(1.28**l)), "clay": int(130*(1.28**l)), "iron": int(150*(1.28**l)), "crop": int(80*(1.28**l))},
        "build_time": lambda l: int(160*(1.4**l)),
    },
    "hospital": {
        "name": "Hospital", "icon": "HP", "category": "village",
        "desc": "Heal wounded troops", "max_level": 20,
        "cost": lambda l: {"wood": int(320*(1.28**l)), "clay": int(280*(1.28**l)), "iron": int(200*(1.28**l)), "crop": int(150*(1.28**l))},
        "build_time": lambda l: int(240*(1.4**l)),
    },
    "laboratory": {
        "name": "Laboratory", "icon": "LB", "category": "military",
        "desc": "Advanced research", "max_level": 10,
        "cost": lambda l: {"wood": int(400*(1.35**l)), "clay": int(380*(1.35**l)), "iron": int(450*(1.35**l)), "crop": int(200*(1.35**l))},
        "build_time": lambda l: int(350*(1.5**l)),
    },
    "fortress": {
        "name": "Fortress", "icon": "FT", "category": "defense",
        "desc": "Boost village defense", "max_level": 20,
        "cost": lambda l: {"wood": int(500*(1.28**l)), "clay": int(450*(1.28**l)), "iron": int(400*(1.28**l)), "crop": int(200*(1.28**l))},
        "build_time": lambda l: int(500*(1.5**l)),
    },
}

# ===== UNITS =====
UNITS = {
    "legionnaire": {
        "name": "Legionnaire", "icon": "LG", "category": "infantry",
        "tribe": "roman", "atk": 40, "def_i": 35, "def_c": 50,
        "speed": 6, "crop": 1,
        "cost": {"wood": 120, "clay": 100, "iron": 150, "crop": 30},
        "train_time": 90, "req": "barracks",
    },
    "praetorian": {
        "name": "Praetorian", "icon": "PR", "category": "infantry",
        "tribe": "roman", "atk": 30, "def_i": 65, "def_c": 35,
        "speed": 5, "crop": 1,
        "cost": {"wood": 100, "clay": 130, "iron": 160, "crop": 30},
        "train_time": 100, "req": "barracks",
    },
    "phalanx": {
        "name": "Phalanx", "icon": "PH", "category": "infantry",
        "tribe": "gaul", "atk": 15, "def_i": 40, "def_c": 50,
        "speed": 7, "crop": 1,
        "cost": {"wood": 100, "clay": 130, "iron": 55, "crop": 30},
        "train_time": 60, "req": "barracks",
    },
    "swordsman": {
        "name": "Swordsman", "icon": "SW", "category": "infantry",
        "tribe": "gaul", "atk": 65, "def_i": 35, "def_c": 20,
        "speed": 6, "crop": 1,
        "cost": {"wood": 140, "clay": 150, "iron": 185, "crop": 60},
        "train_time": 90, "req": "barracks",
    },
    "clubswinger": {
        "name": "Clubswinger", "icon": "CS", "category": "infantry",
        "tribe": "teuton", "atk": 40, "def_i": 20, "def_c": 5,
        "speed": 7, "crop": 1,
        "cost": {"wood": 95, "clay": 75, "iron": 40, "crop": 40},
        "train_time": 45, "req": "barracks",
    },
    "spearman": {
        "name": "Spearman", "icon": "SP", "category": "infantry",
        "tribe": "teuton", "atk": 10, "def_i": 35, "def_c": 60,
        "speed": 7, "crop": 1,
        "cost": {"wood": 145, "clay": 70, "iron": 85, "crop": 40},
        "train_time": 75, "req": "barracks",
    },
    "equites_imp": {
        "name": "Eq. Imperatoris", "icon": "EI", "category": "cavalry",
        "tribe": "roman", "atk": 120, "def_i": 65, "def_c": 50,
        "speed": 14, "crop": 2,
        "cost": {"wood": 550, "clay": 440, "iron": 320, "crop": 100},
        "train_time": 240, "req": "stable",
    },
    "theutates": {
        "name": "Theutates Thunder", "icon": "TT", "category": "cavalry",
        "tribe": "gaul", "atk": 90, "def_i": 25, "def_c": 40,
        "speed": 19, "crop": 2,
        "cost": {"wood": 350, "clay": 450, "iron": 230, "crop": 80},
        "train_time": 180, "req": "stable",
    },
    "paladin": {
        "name": "Paladin", "icon": "PA", "category": "cavalry",
        "tribe": "teuton", "atk": 55, "def_i": 100, "def_c": 40,
        "speed": 10, "crop": 2,
        "cost": {"wood": 370, "clay": 270, "iron": 290, "crop": 75},
        "train_time": 160, "req": "stable",
    },
    "catapult": {
        "name": "Catapult", "icon": "CT", "category": "siege",
        "tribe": "all", "atk": 50, "def_i": 30, "def_c": 10,
        "speed": 4, "crop": 6,
        "cost": {"wood": 950, "clay": 1350, "iron": 600, "crop": 90},
        "train_time": 720, "req": "workshop",
    },
}

# ===== DAILY QUESTS =====
DAILY_QUESTS = [
    {"id": "q_login",   "name": "Daily Login",     "desc": "Log in today",              "type": "login",   "target": 1,   "reward": {"wood": 150, "clay": 150, "iron": 100, "crop": 100}, "xp": 30},
    {"id": "q_build1",  "name": "Builder",         "desc": "Upgrade any building x1",   "type": "build",   "target": 1,   "reward": {"wood": 200, "clay": 200, "iron": 100, "crop": 100}, "xp": 50},
    {"id": "q_build3",  "name": "Engineer",        "desc": "Upgrade 3 buildings today",  "type": "build",   "target": 3,   "reward": {"wood": 500, "clay": 500, "iron": 300, "crop": 200}, "xp": 120},
    {"id": "q_train5",  "name": "Commander",       "desc": "Train 5 military units",     "type": "train",   "target": 5,   "reward": {"wood": 300, "clay": 200, "iron": 400, "crop": 150}, "xp": 80},
    {"id": "q_attack1", "name": "Warrior",         "desc": "Send at least 1 attack",     "type": "attack",  "target": 1,   "reward": {"wood": 400, "clay": 400, "iron": 400, "crop": 400}, "xp": 100},
    {"id": "q_attack3", "name": "Conqueror",       "desc": "Win 3 battles",              "type": "attack",  "target": 3,   "reward": {"wood": 1000,"clay": 800, "iron": 800, "crop": 500}, "xp": 250},
    {"id": "q_res5000", "name": "Merchant",        "desc": "Collect 5000 of any resource","type": "collect","target": 5000,"reward": {"wood": 600, "clay": 600, "iron": 600, "crop": 600}, "xp": 150},
    {"id": "q_social",  "name": "Diplomat",        "desc": "Join alliance or send message","type": "social", "target": 1,   "reward": {"wood": 350, "clay": 350, "iron": 200, "crop": 200}, "xp": 70},
]

# ===== WORLD MAP =====
WORLD_VILLAGES = [
    {"id":1,  "name":"Ghost Village",      "x":2,  "y":3,  "pop":120,  "res":500,   "def":50,   "owner":"NPC", "tribe":"teuton"},
    {"id":2,  "name":"Robbers Camp",       "x":7,  "y":2,  "pop":80,   "res":300,   "def":30,   "owner":"NPC", "tribe":"gaul"},
    {"id":3,  "name":"Dark Fortress",      "x":14, "y":8,  "pop":350,  "res":1200,  "def":200,  "owner":"NPC", "tribe":"teuton"},
    {"id":4,  "name":"Warriors Village",   "x":9,  "y":6,  "pop":200,  "res":800,   "def":120,  "owner":"NPC", "tribe":"roman"},
    {"id":5,  "name":"Wolf Valley",        "x":5,  "y":1,  "pop":60,   "res":200,   "def":20,   "owner":"NPC", "tribe":"gaul"},
    {"id":6,  "name":"Emperor City",       "x":18, "y":17, "pop":1200, "res":8000,  "def":1200, "owner":"NPC", "tribe":"roman"},
    {"id":7,  "name":"Stone Fortress",     "x":12, "y":14, "pop":500,  "res":2000,  "def":400,  "owner":"NPC", "tribe":"teuton"},
    {"id":8,  "name":"Wind Plains",        "x":3,  "y":11, "pop":180,  "res":700,   "def":90,   "owner":"NPC", "tribe":"gaul"},
    {"id":9,  "name":"Watchtower",         "x":16, "y":5,  "pop":250,  "res":900,   "def":150,  "owner":"NPC", "tribe":"roman"},
    {"id":10, "name":"Merchant Port",      "x":8,  "y":18, "pop":400,  "res":1500,  "def":180,  "owner":"NPC", "tribe":"gaul"},
    {"id":11, "name":"Brotherhood",        "x":6,  "y":9,  "pop":300,  "res":1000,  "def":100,  "owner":"Player_Khalid", "tribe":"roman"},
    {"id":12, "name":"Thunder Fort",       "x":11, "y":4,  "pop":450,  "res":1800,  "def":300,  "owner":"Player_Sara",   "tribe":"gaul"},
    {"id":13, "name":"North Castle",       "x":15, "y":12, "pop":700,  "res":3000,  "def":600,  "owner":"Player_Omar",   "tribe":"teuton"},
    {"id":14, "name":"Land of Glory",      "x":4,  "y":16, "pop":220,  "res":850,   "def":130,  "owner":"Player_Nora",   "tribe":"roman"},
    {"id":15, "name":"Golden Shield",      "x":17, "y":9,  "pop":560,  "res":2200,  "def":450,  "owner":"Player_Faris",  "tribe":"teuton"},
]

FAKE_ALLIANCES = [
    {"id":1, "name":"Knights of East", "tag":"KE", "members":24, "power":45000, "rank":1},
    {"id":2, "name":"Desert Shield",   "tag":"DS", "members":18, "power":32000, "rank":2},
    {"id":3, "name":"Northern Lions",  "tag":"NL", "members":31, "power":28000, "rank":3},
    {"id":4, "name":"Valley Guards",   "tag":"VG", "members":12, "power":15000, "rank":4},
    {"id":5, "name":"Empire Builders", "tag":"EB", "members":8,  "power":9000,  "rank":5},
]

ACHIEVEMENTS_DEF = [
    {"id":"ach_build10",  "name":"Builder",     "desc":"Upgrade 10 buildings",  "target":10,   "field":"buildings_built",  "icon":"hammer",       "pts":10},
    {"id":"ach_build50",  "name":"Engineer",    "desc":"Upgrade 50 buildings",  "target":50,   "field":"buildings_built",  "icon":"city-variant", "pts":30},
    {"id":"ach_train20",  "name":"Commander",   "desc":"Train 20 units",        "target":20,   "field":"units_trained",    "icon":"sword",        "pts":10},
    {"id":"ach_train100", "name":"General",     "desc":"Train 100 units",       "target":100,  "field":"units_trained",    "icon":"shield",       "pts":30},
    {"id":"ach_win5",     "name":"Warrior",     "desc":"Win 5 battles",         "target":5,    "field":"attacks_won",      "icon":"trophy",       "pts":20},
    {"id":"ach_win20",    "name":"Conqueror",   "desc":"Win 20 battles",        "target":20,   "field":"attacks_won",      "icon":"crown",        "pts":50},
    {"id":"ach_loot5k",   "name":"Looter",      "desc":"Loot 5000 resources",   "target":5000, "field":"resources_looted", "icon":"cash",         "pts":25},
    {"id":"ach_kill50",   "name":"Destroyer",   "desc":"Destroy 50 enemy units","target":50,   "field":"total_kills",      "icon":"fire",         "pts":20},
    {"id":"ach_lv5",      "name":"Veteran",     "desc":"Reach level 5",         "target":5,    "field":"level",            "icon":"star",         "pts":15},
    {"id":"ach_lv10",     "name":"Master",      "desc":"Reach level 10",        "target":10,   "field":"level",            "icon":"medal",        "pts":40},
]


# ===== PLAYER MODEL =====
class Player:
    VERSION = 4

    def __init__(self):
        self.version        = self.VERSION
        self.name           = "Hero"
        self.tribe          = "roman"
        self.level          = 1
        self.experience     = 0
        self.next_level_xp  = 500
        self.population     = 5
        self.village_name   = "My Village"
        self.village_x      = 10
        self.village_y      = 10

        self.resources      = {"wood": 750.0, "clay": 750.0, "iron": 750.0, "crop": 750.0}
        self.max_resources  = {"wood": 800,   "clay": 800,   "iron": 800,   "crop": 800}
        self.production_rate= {"wood": 30,    "clay": 30,    "iron": 30,    "crop": 30}

        self.buildings = {k: 0 for k in BUILDINGS}
        self.buildings.update({"wood_cutter":1,"clay_pit":1,"iron_mine":1,"cropland":1,"warehouse":1,"granary":1})

        self.army = {k: 0 for k in UNITS}
        self.army["legionnaire"] = 5

        # Stats
        self.attacks_sent    = 0
        self.attacks_won     = 0
        self.resources_looted= 0
        self.buildings_built = 0
        self.units_trained   = 0
        self.total_kills     = 0

        # Alliance
        self.alliance_id    = None
        self.alliance_name  = None
        self.alliance_role  = None

        # Quests
        self.daily_quests_progress  = {"q_login": 1}
        self.daily_quests_completed = []
        self.last_quest_reset       = datetime.now().strftime("%Y-%m-%d")
        self.quests_done_today      = 0

        # Messages
        self.inbox          = []
        self.sent_messages  = []

        # Achievements
        self.achievements       = []
        self.achievement_points = 0

        self.last_update = datetime.now().isoformat()
        self.last_login  = datetime.now().isoformat()

    # ---------- Serialization ----------
    def to_dict(self):
        d = {k: v for k, v in self.__dict__.items() if not callable(v)}
        for r in self.resources:
            d["resources"][r] = float(self.resources[r])
        return d

    @classmethod
    def from_dict(cls, data):
        p = cls.__new__(cls)
        default = cls()
        for k, v in default.__dict__.items():
            setattr(p, k, v)
        for k, v in data.items():
            setattr(p, k, v)
        for r in p.resources:
            p.resources[r] = float(p.resources.get(r, 0))
        for bk in BUILDINGS:
            if bk not in p.buildings:
                p.buildings[bk] = 0
        for uk in UNITS:
            if uk not in p.army:
                p.army[uk] = 0
        return p

    # ---------- Resources ----------
    def update_resources(self):
        try:
            now  = datetime.now()
            last = datetime.fromisoformat(self.last_update)
            hrs  = min((now - last).total_seconds() / 3600, 8)
            for r in self.resources:
                self.resources[r] = min(float(self.resources[r]) + self.production_rate[r] * hrs,
                                        self.max_resources[r])
            self.last_update = now.isoformat()
        except Exception as e:
            print(f"[Player] resource update error: {e}")
            self.last_update = datetime.now().isoformat()

    def can_afford(self, cost):
        return all(float(self.resources.get(r, 0)) >= cost.get(r, 0) for r in cost)

    def deduct(self, cost):
        for r, amt in cost.items():
            self.resources[r] = max(0.0, float(self.resources[r]) - amt)

    def add_resources(self, d):
        for r, amt in d.items():
            self.resources[r] = min(float(self.resources.get(r, 0)) + amt, self.max_resources.get(r, 99999))

    # ---------- Buildings ----------
    def upgrade_building(self, bid):
        b   = BUILDINGS[bid]
        lvl = self.buildings.get(bid, 0)
        if lvl >= b["max_level"]:
            return False, "Max level reached!"
        cost = b["cost"](lvl)
        if not self.can_afford(cost):
            return False, "Not enough resources!"
        self.deduct(cost)
        self.buildings[bid] = lvl + 1
        self.buildings_built += 1
        self.add_xp(50 + lvl * 10)
        self._sync_stats()
        self._quest_progress("build", 1)
        return True, f"{b['name']} upgraded to Lv{lvl+1}!"

    def _sync_stats(self):
        prod_map = {"wood_cutter":"wood","clay_pit":"clay","iron_mine":"iron","cropland":"crop"}
        for bid, res in prod_map.items():
            self.production_rate[res] = max(8, 8 + self.buildings.get(bid, 0) * 9)
        cap = 800 + self.buildings.get("warehouse", 1) * 450
        cc  = 800 + self.buildings.get("granary",   1) * 450
        ft  = self.buildings.get("fortress", 0) * 200
        for r in ["wood","clay","iron"]:
            self.max_resources[r] = cap + ft
        self.max_resources["crop"] = cc + ft
        self.population = 5 + sum(self.buildings.values()) * 2 + self.get_army_count()

    # ---------- Army ----------
    def train_unit(self, uid, count=1):
        u    = UNITS[uid]
        cost = {r: v*count for r, v in u["cost"].items()}
        if not self.can_afford(cost):
            return False, "Not enough resources!"
        req = u.get("req","barracks")
        if self.buildings.get(req, 0) == 0:
            return False, f"Build {BUILDINGS[req]['name']} first!"
        self.deduct(cost)
        self.army[uid] = self.army.get(uid, 0) + count
        self.units_trained += count
        self.add_xp(20 * count)
        self._quest_progress("train", count)
        self._sync_stats()
        return True, f"Trained {count}x {u['name']}!"

    # ---------- Battle ----------
    def conduct_attack(self, village):
        self.attacks_sent += 1
        army = self.get_army_count()
        if army == 0:
            return {"success": False, "msg": "No army to attack with!"}
        atk  = self.get_attack_power()
        win  = min(90, max(10, int((atk / max(1, village["def"])) * 45)))
        roll = random.randint(1, 100)
        if roll <= win:
            self.attacks_won += 1
            loot = {}
            for r in ["wood","clay","iron","crop"]:
                amt = min(int(village["res"] * random.uniform(0.1, 0.3) / 4),
                          self.max_resources[r] - int(self.resources[r]))
                loot[r] = max(0, amt)
            self.add_resources(loot)
            self.resources_looted += sum(loot.values())
            cas  = max(0, int(army * random.uniform(0.02, 0.12)))
            kills= int(village["def"] * random.uniform(0.3, 0.7))
            self._apply_casualties(cas)
            healed = self._hospital(cas)
            self.total_kills += kills
            self.add_xp(100 + kills * 2)
            self._quest_progress("attack", 1)
            return {"success":True,"win":True,"win_chance":win,"loot":loot,
                    "casualties":cas,"healed":healed,"kills":kills,"msg":"Victory!"}
        else:
            cas = int(army * random.uniform(0.2, 0.45))
            self._apply_casualties(cas)
            healed = self._hospital(cas // 2)
            return {"success":True,"win":False,"win_chance":win,"loot":{},
                    "casualties":cas,"healed":healed,"kills":0,"msg":"Defeated!"}

    def _apply_casualties(self, count):
        rem = count
        for uid in list(self.army.keys()):
            if rem <= 0: break
            cur = self.army.get(uid, 0)
            if cur > 0:
                lost = min(cur, rem)
                self.army[uid] -= lost
                rem -= lost

    def _hospital(self, count):
        if self.buildings.get("hospital", 0) == 0 or count == 0:
            return 0
        healed = int(count * min(0.8, 0.3 + self.buildings["hospital"] * 0.025))
        self.army["legionnaire"] = self.army.get("legionnaire", 0) + healed
        return healed

    # ---------- Quests ----------
    def _quest_progress(self, qtype, amount):
        for q in DAILY_QUESTS:
            if q["type"] == qtype and q["id"] not in self.daily_quests_completed:
                self.daily_quests_progress[q["id"]] = self.daily_quests_progress.get(q["id"], 0) + amount

    def claim_quest_reward(self, qid):
        if qid in self.daily_quests_completed:
            return False, "Already claimed!"
        for q in DAILY_QUESTS:
            if q["id"] == qid:
                if self.daily_quests_progress.get(qid, 0) < q["target"]:
                    return False, "Quest not complete yet!"
                self.add_resources(q["reward"])
                self.add_xp(q.get("xp", 50))
                self.daily_quests_completed.append(qid)
                self.quests_done_today += 1
                return True, f"Reward claimed: {q['name']}!"
        return False, "Quest not found!"

    def reset_daily_quests(self):
        today = datetime.now().strftime("%Y-%m-%d")
        if self.last_quest_reset != today:
            self.daily_quests_progress  = {"q_login": 1}
            self.daily_quests_completed = []
            self.last_quest_reset       = today
            self.quests_done_today      = 0

    # ---------- XP / Level ----------
    def add_xp(self, amount):
        self.experience += amount
        while self.experience >= self.next_level_xp:
            self.experience    -= self.next_level_xp
            self.level         += 1
            self.next_level_xp  = int(self.next_level_xp * 1.5)
            bonus = self.level * 100
            self.add_resources({"wood":bonus,"clay":bonus,"iron":bonus,"crop":bonus})

    # ---------- Army Stats ----------
    def get_army_count(self):
        return sum(self.army.values())

    def get_attack_power(self):
        return sum(UNITS[u]["atk"] * c for u, c in self.army.items() if u in UNITS and c > 0)

    def get_defense_power(self):
        return sum(UNITS[u]["def_i"] * c for u, c in self.army.items() if u in UNITS and c > 0)

    # ---------- Messages ----------
    def send_message(self, to, subject, body):
        self.sent_messages.append({"id": len(self.sent_messages)+1, "to": to,
            "subject": subject, "body": body, "time": datetime.now().isoformat(), "read": True})
        self.inbox.append({"id": len(self.inbox)+1, "from": to,
            "subject": f"Re: {subject}",
            "body": f"Thanks for your message, {self.name}! We'll reply soon.",
            "time": datetime.now().isoformat(), "read": False})
        self._quest_progress("social", 1)

    def get_unread_count(self):
        return sum(1 for m in self.inbox if not m.get("read", True))

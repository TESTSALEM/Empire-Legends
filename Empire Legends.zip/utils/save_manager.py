"""
Save Manager - Android / Pydroid3 compatible
"""
import json, os, sys


def get_save_dir():
    candidates = []
    try:
        candidates.append(os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), 'saves'))
    except Exception:
        pass
    candidates += [
        '/sdcard/TravianLegends',
        '/storage/emulated/0/TravianLegends',
        os.path.join(os.path.expanduser('~'), 'TravianLegends'),
        os.path.join(os.getcwd(), 'saves'),
    ]
    ext = os.environ.get('EXTERNAL_STORAGE', '')
    if ext:
        candidates.append(os.path.join(ext, 'TravianLegends'))

    for path in candidates:
        try:
            os.makedirs(path, exist_ok=True)
            test = os.path.join(path, '.wtest')
            open(test, 'w').close()
            os.remove(test)
            print(f"[Save] dir: {path}")
            return path
        except Exception:
            continue
    return os.getcwd()


SAVE_DIR  = get_save_dir()
SAVE_FILE = os.path.join(SAVE_DIR, 'save.json')


def _write(path, data):
    try:
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path) if os.path.exists(path) else os.rename(tmp, path)
        return True
    except Exception:
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"[Save] ERROR: {e}")
            return False


def _read(path):
    for p in [path, path + '.bak']:
        try:
            if os.path.exists(p):
                with open(p, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception:
            continue
    return None


def save_game(player):
    data = player.to_dict()
    ok   = _write(SAVE_FILE, data)
    if ok:
        _write(SAVE_FILE + '.bak', data)
    return ok


def load_game():
    return _read(SAVE_FILE)


def delete_save():
    for f in [SAVE_FILE, SAVE_FILE + '.bak']:
        try:
            if os.path.exists(f): os.remove(f)
        except Exception:
            pass


def get_save_info():
    return {'save_dir': SAVE_DIR, 'save_file': SAVE_FILE,
            'exists': os.path.exists(SAVE_FILE),
            'size': os.path.getsize(SAVE_FILE) if os.path.exists(SAVE_FILE) else 0}

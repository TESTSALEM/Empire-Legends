# دليل نشر Travian Legends على Google Play
## خطوة بخطوة من الهاتف فقط

---

## المرحلة 1: إنشاء مفتاح التوقيع (مرة واحدة فقط)

### في Google Colab:
```python
# الخطوة 1: تثبيت Java
!apt-get install -y default-jdk

# الخطوة 2: ارفع ملفاتك ثم شغّل:
!python3 generate_keystore.py

# الخطوة 3: تنزيل الملفات الناتجة
from google.colab import files
files.download('travian_release.keystore')
files.download('GITHUB_SECRETS.txt')
```

---

## المرحلة 2: إعداد GitHub Secrets

1. افتح Repository على GitHub
2. اذهب لـ: **Settings → Secrets and variables → Actions**
3. اضغط **New repository secret**
4. أضف هذه الأسرار الأربعة من ملف GITHUB_SECRETS.txt:

| الاسم | القيمة |
|-------|--------|
| `KEYSTORE_FILE_BASE64` | النص الطويل المشفر |
| `KEYSTORE_PASSWORD` | كلمة مرور الـ Keystore |
| `KEY_ALIAS` | travian_key |
| `KEY_PASSWORD` | كلمة مرور المفتاح |

---

## المرحلة 3: بناء Release APK

1. في GitHub، اذهب لـ **Actions**
2. اختر **Build Release APK for Google Play**
3. اضغط **Run workflow**
4. انتظر 30-45 دقيقة
5. حمّل الـ APK من **Artifacts**

---

## المرحلة 4: التسجيل في Google Play Console

### الرابط: play.google.com/console

1. ادفع 25$ (مرة واحدة فقط)
2. أكمل معلومات حساب المطور
3. انتظر التحقق (1-3 أيام)

---

## المرحلة 5: إنشاء التطبيق على Google Play

### المتطلبات اللازمة:

#### المعلومات الأساسية:
- **اسم التطبيق:** Travian Legends
- **وصف قصير:** (80 حرف) Build your empire, train your army, conquer the world!
- **وصف مفصل:** (4000 حرف) شرح كامل للعبة

#### الصور المطلوبة:
| النوع | الحجم | ملاحظات |
|-------|-------|---------|
| أيقونة | 512×512 px | PNG بدون خلفية |
| Feature Graphic | 1024×500 px | للصفحة الرئيسية |
| Screenshots | 2 على الأقل | من داخل اللعبة |

#### تقييم المحتوى:
- أجب على أسئلة المحتوى بصدق
- اللعبة: Everyone أو Everyone 10+

---

## المرحلة 6: رفع الـ APK

1. في Play Console: **Testing → Internal testing** (للاختبار أولاً)
2. أو مباشرة: **Production → Create release**
3. ارفع ملف الـ APK
4. أضف ملاحظات الإصدار:
   ```
   Version 1.0.0
   - Initial release
   - Build villages, train armies
   - World map with 15 enemy villages
   - Alliance system
   - Daily quests
   ```
5. اضغط **Review release**
6. اضغط **Start rollout**

---

## المرحلة 7: المراجعة والنشر

- Google تراجع التطبيق: **3-7 أيام** للإصدار الأول
- بعد الموافقة يظهر في المتجر تلقائياً!

---

## الجدول الزمني الكامل

```
اليوم 1:  إنشاء Keystore + بناء APK (2-3 ساعات)
اليوم 1:  التسجيل في Google Play Console ($25)
اليوم 2-4: انتظار التحقق من الحساب
اليوم 4:  رفع التطبيق + الصور والوصف
اليوم 4-11: مراجعة Google (3-7 أيام)
اليوم 12:  🎉 تطبيقك على Google Play!
```

---

## مواقع مفيدة

| الموقع | الاستخدام |
|--------|-----------|
| play.google.com/console | نشر التطبيق |
| github.com | بناء APK مجاناً |
| colab.research.google.com | إنشاء Keystore |
| canva.com | تصميم الصور (أيقونة، screenshots) |
| appFollow.io | تتبع تقييمات المستخدمين |

---

## نصائح مهمة للقبول في Google Play

✅ تأكد من أن التطبيق لا يتعطل
✅ أضف Privacy Policy (يمكن إنشاؤها مجاناً في privacypolicygenerator.info)
✅ الأيقونة والصور بجودة عالية
✅ الوصف واضح وصادق
✅ لا تستخدم كلمة "Travian" في الاسم الرسمي (محمية تجارياً)
   → غيّر الاسم لـ: "Empire Legends" أو "Village Warriors"

---

## تكاليف النشر

| البند | التكلفة |
|-------|---------|
| Google Play Console | $25 مرة واحدة |
| بناء APK (GitHub) | مجاني |
| تصميم الصور (Canva) | مجاني |
| Privacy Policy | مجاني |
| **المجموع** | **$25 فقط** |

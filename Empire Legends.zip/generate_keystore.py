#!/usr/bin/env python3
"""
أداة إنشاء مفتاح التوقيع (Keystore)
شغّل هذا السكريبت مرة واحدة فقط واحفظ المخرجات

يمكن تشغيله في Google Colab:
  !python3 generate_keystore.py
"""
import subprocess
import base64
import os
import sys


def generate_keystore():
    print("=" * 60)
    print("  أداة إنشاء Keystore لـ Google Play")
    print("=" * 60)
    print()

    # معلومات المفتاح
    KEY_ALIAS     = "travian_key"
    KEYSTORE_FILE = "travian_release.keystore"
    VALIDITY_DAYS = 10000   # ~27 سنة

    # اطلب من المستخدم البيانات
    print("أدخل البيانات التالية (باللاتينية):")
    keystore_pass = input("كلمة مرور الـ Keystore (اختر كلمة قوية): ").strip()
    key_pass      = input("كلمة مرور المفتاح (يمكن نفس الأولى): ").strip()
    first_name    = input("اسمك الأول (بالإنجليزية): ").strip() or "Developer"
    last_name     = input("اسمك الأخير (بالإنجليزية): ").strip() or "Name"
    org_name      = input("اسم منظمتك/شركتك (أو اسمك): ").strip() or "Personal"
    country_code  = input("رمز الدولة (SA للسعودية): ").strip() or "SA"

    dname = (f"CN={first_name} {last_name},"
             f"OU={org_name},"
             f"O={org_name},"
             f"L=Riyadh,S=Riyadh,C={country_code}")

    print("\n⏳ جاري إنشاء المفتاح...")

    cmd = [
        "keytool", "-genkeypair",
        "-v",
        "-keystore", KEYSTORE_FILE,
        "-alias",    KEY_ALIAS,
        "-keyalg",   "RSA",
        "-keysize",  "2048",
        "-validity", str(VALIDITY_DAYS),
        "-storepass", keystore_pass,
        "-keypass",   key_pass,
        "-dname",     dname,
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"❌ خطأ: {result.stderr}")
        print("\nتأكد من تثبيت Java:")
        print("  sudo apt-get install default-jdk")
        sys.exit(1)

    print(f"✅ تم إنشاء: {KEYSTORE_FILE}")

    # تحويل لـ Base64 للـ GitHub Secrets
    with open(KEYSTORE_FILE, "rb") as f:
        encoded = base64.b64encode(f.read()).decode()

    # حفظ معلومات GitHub Secrets
    secrets_file = "GITHUB_SECRETS.txt"
    with open(secrets_file, "w") as f:
        f.write("=" * 60 + "\n")
        f.write("  GitHub Secrets - احفظ هذا الملف بأمان!\n")
        f.write("=" * 60 + "\n\n")
        f.write("أضف هذه القيم في: GitHub > Repository > Settings > Secrets\n\n")
        f.write(f"KEYSTORE_FILE_BASE64:\n{encoded}\n\n")
        f.write(f"KEYSTORE_PASSWORD:\n{keystore_pass}\n\n")
        f.write(f"KEY_ALIAS:\n{KEY_ALIAS}\n\n")
        f.write(f"KEY_PASSWORD:\n{key_pass}\n\n")

    print(f"✅ تم حفظ GitHub Secrets في: {secrets_file}")
    print()
    print("=" * 60)
    print("  ⚠️  تحذير مهم جداً!")
    print("=" * 60)
    print(f"  احتفظ بنسخة من: {KEYSTORE_FILE}")
    print(f"  واحتفظ بنسخة من: {secrets_file}")
    print()
    print("  إذا فقدت هذا المفتاح لن تستطيع تحديث تطبيقك")
    print("  على Google Play أبداً!")
    print("=" * 60)


if __name__ == "__main__":
    generate_keystore()

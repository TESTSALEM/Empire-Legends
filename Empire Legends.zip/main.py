"""
Travian Legends - English Edition
- Splash Screen
- Android back button + exit confirmation
- Auto-save
"""
import os, sys

_BASE = None
for _c in [os.path.dirname(os.path.abspath(__file__)),
           os.path.dirname(os.path.abspath(sys.argv[0])), os.getcwd()]:
    if os.path.exists(os.path.join(_c, 'main.py')):
        _BASE = _c; break
if _BASE is None: _BASE = os.getcwd()
if _BASE not in sys.path: sys.path.insert(0, _BASE)
print(f"[Main] BASE: {_BASE}")

os.environ.setdefault("KIVY_NO_ENV_CONFIG", "1")
from kivy.config import Config
Config.set('graphics', 'width',  '400')
Config.set('graphics', 'height', '720')

from kivy.core.window import Window
from kivy.clock import Clock
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.image import Image as KivyImage
from kivy.uix.screenmanager import Screen
from kivy.graphics import Color, Rectangle
from kivy.metrics import dp
from kivymd.app import MDApp
from kivymd.uix.screenmanager import MDScreenManager
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDRaisedButton, MDFlatButton

Window.clearcolor = (0.05, 0.03, 0.01, 1)


# ============================================================
# Splash Screen
# ============================================================
class SplashScreen(Screen):
    def __init__(self, on_done, **kwargs):
        super().__init__(name="splash", **kwargs)
        self.on_done = on_done
        self._build()

    def _build(self):
        layout = FloatLayout()
        with layout.canvas.before:
            Color(0.05, 0.03, 0.01, 1)
            self._bg = Rectangle(pos=layout.pos, size=layout.size)
        layout.bind(pos=self._upd, size=self._upd)

        icon_path = os.path.join(_BASE, 'assets', 'icon.png')
        if os.path.exists(icon_path):
            layout.add_widget(KivyImage(
                source=icon_path,
                size_hint=(None, None), size=(dp(160), dp(160)),
                pos_hint={"center_x": 0.5, "center_y": 0.62}))

        layout.add_widget(Label(text="TRAVIAN", font_size=dp(44), bold=True,
            color=(220/255,155/255,25/255,1), pos_hint={"center_x":0.5,"center_y":0.40}))
        layout.add_widget(Label(text="LEGENDS", font_size=dp(24), bold=True,
            color=(255/255,210/255,80/255,1), pos_hint={"center_x":0.5,"center_y":0.33}))
        layout.add_widget(Label(text="Build. Conquer. Dominate.", font_size=dp(14),
            color=(160/255,130/255,70/255,1), pos_hint={"center_x":0.5,"center_y":0.26}))
        layout.add_widget(Label(text="Loading...", font_size=dp(13),
            color=(100/255,80/255,40/255,1), pos_hint={"center_x":0.5,"center_y":0.12}))
        self.add_widget(layout)

    def _upd(self, *a):
        self._bg.pos  = self.pos
        self._bg.size = self.size

    def on_enter(self):
        Clock.schedule_once(lambda dt: self.on_done(), 2.5)


# ============================================================
# Game Screens
# ============================================================
from screens.welcome_screen  import WelcomeScreen
from screens.village_screen  import VillageScreen
from screens.map_screen      import MapScreen
from screens.alliance_screen import AllianceScreen
from screens.messages_screen import MessagesScreen
from screens.quests_screen   import QuestsScreen
from screens.stats_screen    import StatsScreen
from game_data import Player
from utils.save_manager import load_game, save_game, get_save_info


class TravianApp(MDApp):

    def build(self):
        self.theme_cls.theme_style     = "Dark"
        self.theme_cls.primary_palette = "Amber"
        self.theme_cls.accent_palette  = "DeepOrange"
        self.title       = "Travian Legends"
        self._exit_dlg   = None

        self.sm = MDScreenManager()
        self.sm.player = None

        self.sm.add_widget(SplashScreen(on_done=self._after_splash))
        self.sm.add_widget(WelcomeScreen(name="welcome"))
        self.sm.add_widget(VillageScreen(name="village"))
        self.sm.add_widget(MapScreen(name="map"))
        self.sm.add_widget(AllianceScreen(name="alliance"))
        self.sm.add_widget(MessagesScreen(name="messages"))
        self.sm.add_widget(QuestsScreen(name="quests"))
        self.sm.add_widget(StatsScreen(name="stats"))
        self.sm.current = "splash"

        Window.bind(on_keyboard=self._on_kb)
        Clock.schedule_interval(self._autosave, 60)
        return self.sm

    # ---- Splash done ----
    def _after_splash(self):
        info  = get_save_info()
        print(f"[Main] Save: {info['save_file']} exists={info['exists']}")
        saved = load_game()
        if saved:
            try:
                p = Player.from_dict(saved)
                self.sm.player  = p
                self.sm.current = "village"
                print(f"[Main] Loaded: {p.name}")
            except Exception as e:
                print(f"[Main] Load error: {e}")
                self.sm.current = "welcome"
        else:
            self.sm.current = "welcome"

    # ---- Android back button ----
    def _on_kb(self, window, key, *args):
        if key not in (27, 1001):
            return False
        cur = self.sm.current
        if cur in ("village", "welcome", "splash"):
            self._ask_exit(); return True
        nav = {"map":"village","alliance":"village",
               "messages":"village","stats":"village","quests":"map"}
        if cur in nav:
            self.sm.current = nav[cur]; return True
        return False

    def _ask_exit(self):
        if self._exit_dlg: return
        self._exit_dlg = MDDialog(
            title="Exit Game?",
            text="Are you sure you want to exit Travian Legends?\nYour progress is saved automatically.",
            buttons=[
                MDFlatButton(text="Cancel",
                    on_release=lambda x: self._close_exit()),
                MDRaisedButton(text="Exit",
                    md_bg_color=(0.7,0.1,0.1,1),
                    on_release=lambda x: self._do_exit()),
            ])
        self._exit_dlg.open()

    def _close_exit(self, *a):
        if self._exit_dlg:
            self._exit_dlg.dismiss()
            self._exit_dlg = None

    def _do_exit(self, *a):
        self._close_exit()
        if self.sm.player: save_game(self.sm.player)
        self.stop()

    # ---- Save ----
    def _autosave(self, dt):
        if self.sm and self.sm.player: save_game(self.sm.player)

    def on_pause(self):
        if self.sm and self.sm.player: save_game(self.sm.player)
        return True

    def on_resume(self):
        if self.sm and self.sm.player: self.sm.player.update_resources()

    def on_stop(self):
        if self.sm and self.sm.player: save_game(self.sm.player)


if __name__ == "__main__":
    TravianApp().run()

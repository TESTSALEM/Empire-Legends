[app]

# ===== App Info =====
title           = Travian Legends
package.name    = travianlegends
package.domain  = com.travian.python

source.dir      = .
source.include_exts = py,png,jpg,jpeg,atlas,json,ttf,kv
source.include_patterns = assets/*.png, assets/*.jpg, fonts/*.ttf, saves/

version = 2.0

# ===== Requirements =====
# Only stable, well-tested packages - no arabic_reshaper needed
requirements = python3==3.14.2,kivy==2.3.0,kivymd==1.2.0,pillow


# ===== Icon & Splash =====
icon.filename     = %(source.dir)s/assets/icon.png
presplash.filename= %(source.dir)s/assets/presplash.png
presplash.lottie  = False

# Presplash background color (dark theme)
android.presplash_color = #0D0802

# ===== Orientation =====
orientation = portrait
fullscreen  = 0

# ===== Android Settings =====
android.permissions = WRITE_EXTERNAL_STORAGE,READ_EXTERNAL_STORAGE,INTERNET
android.api         = 33
android.minapi      = 24
android.ndk         = 25b
android.sdk         = 33
android.ndk_api     = 24
android.archs       = arm64-v8a, armeabi-v7a
android.allow_backup= True
android.release_artifact = apk
android.enable_androidx  = True

# App entry point
android.entrypoint = org.kivy.android.PythonActivity

# ===== Gradle =====
android.gradle_dependencies =

# ===== p4a =====
p4a.branch = master

[buildozer]
log_level    = 2
warn_on_root = 1
build_dir    = ./.buildozer
bin_dir      = ./bin
